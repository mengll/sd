# _*_ coding: utf8 _*_

from kafka import KafkaConsumer
from LogStruct import LogStruct

if __name__ == "__main__":
    kafka_consumer = KafkaConsumer(bootstrap_servers="172.18.253.195:9092,172.18.254.24:9092,172.18.254.23:9092",
                                   # group_id=Config().get_config('kafka', 'group_id'),
                                   group_id='async_login',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
    kafka_consumer.subscribe(["weblog_log"])
    for msg in kafka_consumer:
        #print(msg.value)
        cont = msg.value.decode('utf-8')

        print(cont)
        itm = LogStruct()
        itm.undumps(cont)