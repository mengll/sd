# _*_ coding:# _*_ coding: utf-8 _*_
# @Time    : 2018/7/17 下午1:41
# @Author  : 杨楚杰
# @File    : common_old.py.py
# @license : Copyright(C), 安锋游戏
import base64
import datetime
import hashlib
import json
import time
import uuid
from urllib.parse import urlencode

import os
import requests
from bs4 import BeautifulSoup
from kafka import KafkaProducer
from selenium import webdriver
from selenium.webdriver import DesiredCapabilities

from common.YDMHTTP import YDMHttp
from conf.config import get_config

MEDIA = {
    'BAIDU': '百度',
    'TOUTIAO': '今日头条',
    'UC': 'UC头条',
    'gdt': '广点通',
}

#  常量定义
CONSTANT = {
    "UA": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:61.0) Gecko/20100101 Firefox/61.0",
}

def get_random_uuid():
    return uuid.uuid4()

def get_current_datetime():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(time.time())))

def get_current_date():
    return time.strftime("%Y-%m-%d", time.localtime(int(time.time())))

def get_current_date_int():
    return int(time.strftime("%Y-%m-%d", time.localtime(int(time.time()))).replace('-', ''))

def get_input_timestamp(inp):
    return int(time.strftime("%Y-%m-%d", time.localtime(int(inp))).replace('-', ''))

def get_current_timestamp():
    return int(time.time() * 1000)

def af_base64(data):
    return base64.b64encode(data)


def url_encode(data):
    return urlencode(data)


# 腾讯广点通计算g_td参数的算法
def gdt_g_tk(skey=''):
    hash = 5381
    for i in range(len(skey)):
        hash += (hash << 5) + ord(skey[i])
    return hash & 0x7fffffff


# 使用新版本的chrome无头浏览器，因为 phantomjs 存在很多bug并且现在已经不再维护
def get_webdriver():
    dcap = dict(DesiredCapabilities.PHANTOMJS)
    dcap["phantomjs.page.settings.userAgent"] = (CONSTANT['UA'],)
    chrome_options = webdriver.ChromeOptions()
    # chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--window-size=1280,1696')  # 设置下窗口大小，因为发现uc的界面中验证码会被遮挡住
    chrome_driver_binary = 'E:\\tool\\chromedriver\\chromedriver.exe'
    #return webdriver.Chrome(chrome_driver_binary,chrome_options=chrome_options, desired_capabilities=dcap)
    return webdriver.Chrome(chrome_options=chrome_options, desired_capabilities=dcap,executable_path=chrome_driver_binary)

#  添加落地页素材下载请求到队列
def send_pic_download_queue(data):
    print("【图片资源】",data)
    # kafka_producer.send(get_config('kafka', 'img_topic'), str(json.dumps(data)).encode("utf-8"))

# 解析今日头条建站落地页的素材文件
def parse_request_img(ad_id, site_name, account_name, url,data=None):
    img_list = []
    UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 " \
         "Safari/537.36 "
    #  处理在今日头条上建的落地页素材
    if "ad.toutiao.com" in url:
        res = requests.get(url, headers={
            "User-Agent": UA
        }, allow_redirects=True)
        soup = BeautifulSoup(res.text)
        for iframe in soup.findAll('iframe'):
            content = requests.get("http:%s" % iframe.get("src"), headers={
                "User-Agent": UA
            }, allow_redirects=True,cookies=data['cookie'])

            soup = BeautifulSoup(content.text)
            for index, img in enumerate(soup.findAll("img")):

                data = {
                    '_id': "%s_%s" % (ad_id, index),
                    'site_name': site_name,
                    'account_name': account_name,
                    'res_type': 'ldy',
                    'img_url': img.get("src")
                }
                img_list.append(img.get("src"))
                send_pic_download_queue(data)
    else:
        try:
            content = requests.get(url, headers={
                "User-Agent": UA
            }, allow_redirects=True,cookies=data['cookie'])
        except Exception as e:
            print(data)
            os._exit(1)

        soup = BeautifulSoup(content.text)
        for index, img in enumerate(soup.findAll("img")):
            img_src = img.get("src")
            if "http" not in img.get("src"):
                img_src = "http:%s" % img.get("src")
            data = {
                '_id': "%s_%s" % (ad_id, index),
                'site_name': site_name,
                'account_name': account_name,
                'res_type': 'ldy',
                'img_url': img_src
            }
            img_list.append(img.get("src"))
            send_pic_download_queue(data)
    return img_list

# 获取正确的图片地址
def get_real_path(pk,path_url='',backdata = ''):
    path = path_url
    for k in pk :
        path = os.path.join(path,k)
        if not os.path.exists(path):
            os.makedirs(path)

    file_path = os.path.join(path,backdata)
    if path_url is not '':
        os.makedirs(os.path.dirname(path),mode=0o777,exist_ok=True)
        if backdata is not '':
            if os.path.exists(file_path) == False:
                f = open(file_path, 'w')
                f.close()
                #官居一品-爪游02
    return file_path

# 获取Kafka的
#kafka_producer = KafkaProducer(bootstrap_servers=get_config('kafka', 'uri'))

def log(*args,**kwargs):
    print("【%s】"%args,kwargs,"\n\t")

# yundama_client = YDMHttp(get_config('yundama', 'username'),
#                          get_config('yundama', 'password'),
#                          get_config('yundama', 'appid'),
#                          get_config('yundama', 'appkey'))
#

# uid = yundama_client.login()
# balance = yundama_client.balance()
# if balance < 100:
#     print('云打码账户余额不足： %s' % balance)

def log(*args,**kwargs):
    print("【%s】"%args,kwargs,"\n\t")

def get_yesterday(n = 1):
    today=datetime.date.today()
    oneday=datetime.timedelta(days=n)
    yesterday=today-oneday
    return yesterday

# 获取视频文件的MD5
def get_file_md5(file):
    buffer_size = 1024 * 1024  # 缓冲大小,这里表示1MB
    md5obj = hashlib.md5()
    with open(file, 'rb') as f:
        while True:
            content = f.read(buffer_size)  # 每次读取指定字节
            if content:
                md5obj.update(content)
            else:
                break  # 当内容为空时,终止循环

    md5 = md5obj.hexdigest()
    print(md5)  # 打印md5值
    return md5  # 返回文件的MD5

# 获取字符串的MD5
def get_obj_md5(obj: object) -> object:
    md5obj = hashlib.md5()
    md5obj.update(str(obj).encode('utf-8'))
    return md5obj.hexdigest()


# 加载当前的文件配置
def get_path():
    path = os.path.split(os.path.realpath(__file__))[0]
    return os.path.dirname(path)

# 获取前N天的时间戳
def get_bf_day(day):
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=day)
    yesterday_start_time = int(time.mktime(time.strptime(str(yesterday), '%Y-%m-%d')))
    return yesterday_start_time


def get_time_stmp(int_date=20171211, n=1):
    try:
        gave_date = datetime.datetime.strptime(str(int_date), "%Y%m%d")
        start = gave_date + datetime.timedelta(days=n)
        n -= 1
        # start_date = gave_date.strftime('%Y%m%d')
        # end_date = start.strftime('%Y%m%d')
        start_date = gave_date.timestamp()
        end_date = start.timestamp()
        return int(start_date), int(end_date)
    except Exception as e:
        print(e)