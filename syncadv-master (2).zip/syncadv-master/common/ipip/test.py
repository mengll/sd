import os
from common.ipip.ipip import IP

IP.load(os.path.dirname(__file__) + "/17monipdb.dat")


def cv(x):
    return '.'.join([str(x/(256**i)%256) for i in range(3,-1,-1)])


def getCity(ip):
    if isinstance(ip,(int, long)):
        ip=cv(ip)
    city= IP.find(ip).replace("\t", ' ')

    return city


print(getCity('106.75.146.42'))
print(getCity('58.49.58.52'))
print(getCity('127.0.0.1'))
