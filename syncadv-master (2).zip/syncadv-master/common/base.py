# _*_ coding: utf-8 _*_
# @Time    : 2018/5/9 下午3:20
# @Author  : 杨楚杰
# @File    : etl_base.py
# @license : Copyright(C), 安锋游戏

"""
ETL 清洗程序的基类
"""
from common.config import Config


class etl_base(object):
    def __init__(self, run_mode=None, node_name=None, process_mark=None, extra=None):
        self.run_mode = run_mode
        self.node_name = node_name
        self.process_mark = process_mark
        self.extra = extra
        self.company_name = Config().get_config('company', 'name')

    def arg_check(self):
        if not self.run_mode or not self.node_name or not self.process_mark:
            print("当前运营商：%s, 构造函数中 run_mode、node_name、process_name 参数不能为空" % self.company_name)
            exit(1)

    def start_main_service(self):
        self.arg_check()
        print("开始启动: %s, 【%s】 业务的清洗 ..." % (self.company_name, self.run_mode))
        self.main_service()

    def main_service(self):
        pass



"""
离线统计程序的基类
"""


class offline_statis_base(object):

    def __init__(self, run_mode=None, start_date=None, end_date=None):
        self.run_mode = run_mode
        self.start_date = start_date
        self.end_date = end_date
        self.company_name = Config().get_config('company', 'name')

    def start_main_service(self):
        print("开始执行【%s】的离线计算 ..." % self.company_name)
        self.main_service()

    def main_service(self):
        pass


"""
同步程序的基类
"""


class sync_base(object):

    def __init__(self, origin_db=None, target_db=None, company_id=None):
        self.origin_db = origin_db
        self.target_db = target_db
        self.company_id = company_id

    def main_service(self):
        pass