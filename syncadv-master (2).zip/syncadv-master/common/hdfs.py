# _*_ coding: utf-8 _*_
# @Time    : 2017/11/6 上午11:25
# @Author  : 杨楚杰
# @File    : hdfs.py
# @license : Copyright(C), 安锋游戏
from hdfs import Client
from hdfs import HdfsError
from common import debug_logger

class HDFS_Until:
    def __init__(self, host, port):
        try:
            self.hdfs_client = Client('http://{host}:{port}'.format(host=host, port=port))
        except HdfsError as e:
            debug_logger.exception(e.exception)

    def get_dirs(self, path='/'):
        try:
            return self.hdfs_client.list(path)
        except HdfsError as e:
            debug_logger.exception(e.exception)
        return []

    def create_dirs(self, path=None):
        if path:
            try:
                self.hdfs_client.makedirs(path)
                return True
            except HdfsError as e:
                debug_logger.exception(e.exception)
        return False

    def delete_dirs(self, path=None):
        if path:
            try:
                self.hdfs_client.delete(path, recursive=True)
                return True
            except HdfsError as e:
                debug_logger.exception(e.exception)
        return False

    def write_file(self, path=None, data=None):
        if data and path:
            try:
                self.hdfs_client.write(path, data=data)
                return True
            except HdfsError as e:
                debug_logger.exception(e.exception)
        return False

    def upload_file(self, hdfs_path=None, source_file_path=None):
        if hdfs_path and source_file_path:
            try:
                self.hdfs_client.upload(hdfs_path, source_file_path, overwrite=True)
                return True
            except HdfsError as e:
                debug_logger.exception(e.exception)
        return False
