# _*_ coding: utf-8 _*_
# @Time    : 2018/5/9 下午7:14
# @Author  : 杨楚杰
# @File    : models.py
# @license : Copyright(C), 安锋游戏
from sqlalchemy import Column
from sqlalchemy import DateTime
from sqlalchemy import Integer
from sqlalchemy import String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class User_Meta_Data(Base):
    __tablename__ = 'ty_user_meta_data'
    id = Column(Integer, primary_key=True)
    ucid = Column(Integer)
    pid = Column(Integer)
    rid = Column(Integer)
    create_time = Column(DateTime)
    create_date = Column(Integer)
    mobile = Column(String)
    uid = Column(String)
    nickname = Column(String)
    imei = Column(String)
    device_id = Column(String)
    last_login_time = Column(DateTime)
    page_id = Column(Integer)
    location = Column(String)
    ip = Column(String)

    def __repr__(self):
        return '<User %s - %s>' % (self.ucid, self.device_id)
