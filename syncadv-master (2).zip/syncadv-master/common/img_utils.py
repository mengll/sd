# _*_ coding: utf-8 _*_
# @Time    : 2018/7/11 下午4:09
# @Author  : 杨楚杰
# @File    : ImgUntil.py
# @license : Copyright(C), 安锋游戏
# import piexif
# import piexif.helper
# from PIL import Image
# from PIL.ExifTags import TAGS
#
#
# #  添加图片扩展标记
# def add_exif_data(filename, new_file, user_comment):
#     exif_ifd = {piexif.ExifIFD.UserComment: piexif.helper.UserComment.dump(user_comment)}
#     exif_dict = {"Exif": exif_ifd}
#     exif_bytes = piexif.dump(exif_dict)
#     im = Image.open(filename)
#     im.save(new_file, exif=exif_bytes)
#
#
# def get_exif_data(img_path):
#     ret = {}
#     try:
#         img = Image.open(img_path)
#         if hasattr(img, '_getexif'):
#             exifinfo = img._getexif()
#             if exifinfo is not None:
#                 for tag, value in exifinfo.items():
#                     decoded = TAGS.get(tag, tag)
#                     ret[decoded] = value
#     except IOError as e:
#         print(e.message)
#     if 'UserComment' in ret:
#         ret['UserComment'] = str(piexif.helper.UserComment.load(ret['UserComment']))
#     return ret


# if __name__ == '__main__':
#     add_exif_data("/Users/anfeng/PycharmProjects/AnfengToufangSpider/images/ldy/90084284_0.jpg",
#                   "/Users/anfeng/PycharmProjects/AnfengToufangSpider/images/ldy/ttt.jpg", "test_exif")
#
#     ret = get_exif_data("/Users/anfeng/PycharmProjects/AnfengToufangSpider/images/ldy/ttt.jpg")
#     print ret
