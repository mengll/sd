# _*_ coding: utf-8 _*_
# @Time    : 2018/7/9 下午5:30
# @Author  : 杨楚杰
# @File    : YDMHTTP.py
# @license : Copyright(C), 安锋游戏
import http.client, mimetypes, urllib,json, time, requests

from urllib3 import encode_multipart_formdata

"""
    云打码提供的sdk
"""

# 定义错误
PASS_WORD_ERR = -1001  # 密码错误
KEY_ERR       = -1002  # 软件id/密钥有误
IP_LIMIT      = -1004  # IP被封
NO_MONEY      = -1007  # 没钱了
FILE_TYPE_ERR = -2003  # 验证码损坏
TIME_OUT      = -3003  # 图片识别超时
UPLOAD_FILE_ERR = -2004 # 上传验证码失败
IS_NOT_CLEAR    = -3004 # 验证码看不清

class YDMHttp:
    apiurl = 'http://api.yundama.com/api.php'
    username = ''
    password = ''
    appid = ''
    appkey = ''

    def __init__(self, username, password, appid, appkey):
        self.username = username
        self.password = password
        self.appid = str(appid)
        self.appkey = appkey

    def request(self, fields, files=[]):
        response = self.post_url(self.apiurl, fields, files)
        response = json.loads(response)
        return response

    def balance(self):
        data = {'method': 'balance', 'username': self.username, 'password': self.password, 'appid': self.appid,
                'appkey': self.appkey}
        response = self.request(data)
        if response:
            if response['ret'] and response['ret'] < 0:
                return response['ret']
            else:
                return response['balance']
        else:
            return -9001

    def login(self):
        data = {'method': 'login', 'username': self.username, 'password': self.password, 'appid': self.appid,
                'appkey': self.appkey}
        response = self.request(data)
        if response:
            if response['ret'] and response['ret'] < 0:
                return response['ret']
            else:
                return response['uid']
        else:
            return -9001

    def upload(self, filename, codetype, timeout):
        data = {'method': 'upload', 'username': self.username, 'password': self.password, 'appid': self.appid,
                'appkey': self.appkey, 'codetype': str(codetype), 'timeout': str(timeout)}
        file = {'file': filename}
        response = self.request(data, file)
        if response:
            if response['ret'] and response['ret'] < 0:
                return response['ret']
            else:
                return response['cid']
        else:
            return -9001

    def result(self, cid):
        data = {'method': 'result', 'username': self.username, 'password': self.password, 'appid': self.appid,
                'appkey': self.appkey, 'cid': str(cid)}
        response = self.request(data)
        return response and response['text'] or ''

    def decode(self, filename, codetype, timeout):
        print("【上传文件路径】=>",filename)
        cid = self.upload(filename, codetype, timeout)
        print("【文件上传后id】",cid)
        if cid > 0:
            for i in range(0, int(timeout)):
                result = self.result(cid)
                if result != '':
                    return cid, result
                else:
                    time.sleep(1)
            return -3003, ''

        if cid == FILE_TYPE_ERR:
            print("【云打码】验证码损坏")

        if cid  == PASS_WORD_ERR:
            print("【云打码】密码错误")

        if cid  == KEY_ERR:
            print("【云打码】软件id/密钥有误")

        if cid  == IP_LIMIT:
            print("【云打码】IP被封")

        if cid == NO_MONEY:
            print("【云打码】没钱了")

        if cid == TIME_OUT:
            print("【云打码】图片识别超时")

        if cid == UPLOAD_FILE_ERR:
            print("【云打码】上传验证码失败")

        if cid  == IS_NOT_CLEAR:
            print("【云打码】验证码看不清")

        return cid ,''



    def report(self, cid):
        data = {'method': 'report', 'username': self.username, 'password': self.password, 'appid': self.appid,
                'appkey': self.appkey, 'cid': str(cid), 'flag': '0'}
        response = self.request(data)
        if response:
            return response['ret']
        else:
            return -9001

    def post_url(self, url, fields, files=[]):
        data = {'enctype': 'multipart/form-data'}
        for key in files:
            files[key] = open(files[key], 'rb');
        res = requests.post(url, files=files, data=data)
        return res.text

    def post_files(url, header, data, filename, filepath):
        """
            :param files: (optional) Dictionary of ``'name': file-like-objects`` (or ``{'name': file-tuple}``) for multipart encoding upload.
            ``file-tuple`` can be a 2-tuple ``('filename', fileobj)``, 3-tuple ``('filename', fileobj, 'content_type')``
            or a 4-tuple ``('filename', fileobj, 'content_type', custom_headers)``, where ``'content-type'`` is a string
            defining the content type of the given file and ``custom_headers`` a dict-like object containing additional headers
            to add for the file.
        """
        data['file'] = (filename, open(filepath, 'rb').read())
        encode_data = encode_multipart_formdata(data)
        data = encode_data[0]
        header['Content-Type'] = encode_data[1]
        r = requests.post(url, headers=header, data=data)


