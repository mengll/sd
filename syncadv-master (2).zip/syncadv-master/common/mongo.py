# _*_ coding: utf8 _*_
from pymongo import MongoClient
from common.config import Config

class mongodb(object):
    def mongo_init(self, selection="mongodb"):
        url = Config().get_config(selection, 'db_url')
        print(url)
        mongo_client = MongoClient(url)
        return mongo_client


if __name__ == '__main__':
    mongo = mongodb()
    mongo_client = mongo.mongo_init()
    md = mongo_client['log']
    user_collection = md['device_info_log']
    cour = user_collection.find({'pid': {'$exists': 1}}).count(with_limit_and_skip=True)
    print(cour)
