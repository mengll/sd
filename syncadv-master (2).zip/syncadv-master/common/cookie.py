# _*_ coding: utf-8 _*_
# @Time    : 2018/7/10 下午2:46
# @Author  : 杨楚杰
# @File    : cookie.py.py
# @license : Copyright(C), 安锋游戏
import json
import re
import os

from common.common import get_real_path

current_path = os.path.dirname(__file__)

def save_user_cookie(media, key, cookie_jar):
    try:
        pl = ['cookies',media]

        # cookie_dir_path = '{path}/cookies/{media}/'.format(path=current_path, media=media)
        cookie_dir_path = get_real_path(pl,path_url=current_path,backdata='{k}.txt'.format(k=key))
        print("【cookie_path】",cookie_dir_path)

        if cookie_jar:
            text_url = get_real_path(['cookies',media],path_url=current_path,backdata='{k}.txt'.format(k=key))
            # '{path}/cookies/{media}/{key}.txt'.format(path=current_path, media=media, key=key)
            print("【cookie_file】",text_url)
            if os.path.exists(text_url):
                with open(text_url , 'w') as f:
                    for cookie in cookie_jar:
                        f.write(json.dumps(cookie) + '\n')
        else:
            print("cookie 为空")
    except Exception as e:
        print("【保存cookie失败】",e.message)


def get_user_cookie(media, key):
    cookie = {}
    try:
        text_url = get_real_path(['cookies', media],path_url=current_path,backdata='{k}.txt'.format(k=key))
        # '{path}/cookies/{media}/{key}.txt'.format(path=current_path, media=media, key=key)
        if os.path.exists(text_url):
            print("【将要打开的地址】",text_url)
            with open(text_url, 'r') as f:
                for line in f.readlines():
                    obj = json.loads(line)
                    cookie[obj['name']] = obj['value']
    except Exception as e:
        print("【获取cookie异常】",e)
    return cookie

