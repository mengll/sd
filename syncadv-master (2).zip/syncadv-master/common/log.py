# _*_ coding: utf-8 _*_
# @Time    : 2018/7/17 上午11:59
# @Author  : 杨楚杰
# @File    : log.py.py
# @license : Copyright(C), 安锋游戏
import logging

logger = logging.getLogger('spider_logger')
logger.setLevel(logging.INFO)

fh = logging.handlers.TimedRotatingFileHandler(
        "logs/spiders.log", 'D', 1, 0)
fh.suffix = "%Y%m%d"
fh.setLevel(logging.ERROR)

ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'.encode(encoding='utf-8'))
fh.setFormatter(formatter)
ch.setFormatter(formatter)

logger.addHandler(fh)
logger.addHandler(ch)

