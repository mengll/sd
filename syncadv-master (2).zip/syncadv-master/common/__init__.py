# _*_ coding: utf-8 _*_
# @Time    : 2017/11/2 上午11:28
# @Author  : 杨楚杰
# @File    : __init__.py.py
# @license : Copyright(C), 安锋游戏
import datetime
import json
import logging
from logging import handlers
import os
import sys
import time
from logging.handlers import TimedRotatingFileHandler

debug_logger = logging.getLogger('DEBUG_LOGGER')
hdfs_logger = logging.getLogger('HDFS_LOGGER')

project_dir = os.path.dirname(os.path.abspath(__file__))

hdfs_formatter = logging.Formatter('%(message)s')
hdfs_handler = handlers.RotatingFileHandler(project_dir + '/../logs/hdfs/data.log',
                                            'a', 104857600, 5)

debug_formatter = logging.Formatter('[%(asctime)s] [%(filename)s:%(lineno)d] %(levelname)s - %(message)s')
debug_handler = TimedRotatingFileHandler(project_dir + '/../logs/debug.log', when='midnight',
                                         interval=1, backupCount=30)
debug_handler.setFormatter(debug_formatter)

debug_logger.setLevel(logging.INFO)
hdfs_logger.setLevel(logging.INFO)

debug_logger.addHandler(debug_handler)
hdfs_logger.addHandler(hdfs_handler)


def record_data_report_to_hdfs(data):
    data_json = json.loads(data)
    log_name_format = "datalog-{vid}-{pid}-{rid}-{year}-{month}-{day}.log"
    # todo  vid 后面要改成根据pid查询
    record_time = datetime.datetime.strptime(time.strftime('%Y-%m-%d', time.localtime(data_json['ts'])), '%Y-%m-%d')
    log_name = log_name_format.format(vid=1, pid=data_json['header']['appid'],
                                      rid=data_json['header']['channelId'],
                                      year=record_time.year,
                                      month=record_time.month, day=record_time.day)
    for h in hdfs_logger.handlers:
        hdfs_logger.removeHandler(h)
    file_path = '/../logs/hdfs/' + log_name
    target_hdfs_handler = handlers.RotatingFileHandler(project_dir + file_path,
                                                       'a', 104857600, 5)
    hdfs_logger.addHandler(target_hdfs_handler)

    log_data = {
        "ver": data_json.get('ver', '0'),
        "ts": data_json.get('ts', 0),
        "ip": data_json.get('ip', '0'),
        "lng": data_json.get('lng', '0'),
        "lat": data_json.get('lat', '0'),

        "uid": data_json.get('header', {}).get('uid', 'NA'),
        "platform": data_json.get('header', {}).get('platform', 'NA'),
        "appid": data_json.get('header', {}).get('appid', 'NA'),
        "channel_id": data_json.get('header', {}).get('channelId', 'NA'),
        "app_version": data_json.get('header', {}).get('appVersion', 'NA'),
        "compaign_id": data_json.get('header', {}).get('compaignId', 'NA'),
        "province": data_json.get('header', {}).get('province', 'NA'),
        "operator": data_json.get('header', {}).get('operator', 'NA'),
        "city": data_json.get('header', {}).get('city', 'NA'),
        "area": data_json.get('header', {}).get('area', 'NA'),
        "country": data_json.get('header', {}).get('country', 'NA'),
        "sdk_version": data_json.get('header', {}).get('sdkVersion', 'NA'),
        "start_id": data_json.get('header', {}).get('start_id', 'NA'),
        "ua": data_json.get('header', {}).get('ua', 'NA'),

        "screen": data_json.get('extHeader', {}).get('screen', 'NA'),
        "os": data_json.get('extHeader', {}).get('os', 'NA'),
        "model": data_json.get('extHeader', {}).get('model', 'NA'),
        "root": data_json.get('extHeader', {}).get('root', 'NA'),
        "adr_id": data_json.get('extHeader', {}).get('adrId', 'NA'),
        "cpu": data_json.get('extHeader', {}).get('cpu', 'NA'),
        "pkg": data_json.get('extHeader', {}).get('pkg', 'NA'),
        "mac": data_json.get('extHeader', {}).get('mac', 'NA'),
        "imei1": data_json.get('extHeader', {}).get('imei1', 'NA'),
        "net": data_json.get('extHeader', {}).get('net', 'NA'),
        "lang": data_json.get('extHeader', {}).get('lang', 'NA'),
        "sign": data_json.get('extHeader', {}).get('sign', 'NA'),
        "imsi1": data_json.get('extHeader', {}).get('imsi1', 'NA'),
        "session_time": data_json.get('extHeader', {}).get('sessionTime', 'NA'),
        "tz": data_json.get('extHeader', {}).get('tz', 'NA'),
        "manu": data_json.get('extHeader', {}).get('manu', 'NA'),
        "oper": data_json.get('extHeader', {}).get('oper', 'NA'),
        "oper_iso": data_json.get('extHeader', {}).get('operISO', 'NA'),
        "brand": data_json.get('extHeader', {}).get('brand', 'NA'),
        "has_role_system": data_json.get('extHeader', {}).get('hasRoleSystem', 'NA'),
        "idfv": data_json.get('extHeader', {}).get('idfv', 'NA'),
        "app_ver": data_json.get('extHeader', {}).get('appVer', 'NA'),
        "upload_interval": data_json.get('extHeader', {}).get('uploadInterval', 'NA'),
        "utm_num": data_json.get('extHeader', {}).get('utm_num', 'NA'),
        "device_name": data_json.get('extHeader', {}).get('deviceName', 'NA'),
        "bundle_id": data_json.get('extHeader', {}).get('bundleId', 'NA'),
        "jia_break": data_json.get('extHeader', {}).get('jiaBreak', 'NA'),
        "idfa": data_json.get('extHeader', {}).get('idfa', 'NA'),
        "simulator": data_json.get('extHeader', {}).get('simulator', 'NA'),
    }

    event_list = data_json.get('EventList', [])
    for event_item in event_list:
        e = {
            "event_type": event_item.get('eventType', 'NA'),
            "imei2": event_item.get('imei2', 'NA'),
            "mac": event_item.get('mac', 'NA'),
            "imei1": event_item.get('imei1', 'NA'),
            "idfv": event_item.get('idfv', 'NA'),
            "idfa": event_item.get('idfa', 'NA'),
            "event_id": event_item.get('eventId', 'NA'),
            "account_id": event_item.get('accountId', 'NA'),
            "area_id": event_item.get('areaId', 'NA'),
            "area_account_id": event_item.get('areaAccountId', 'NA'),
            "app_data": json.dumps(event_item.get('appData', {}), ensure_ascii=False),
            "custome_data": json.dumps(event_item.get('customeData', {}), ensure_ascii=False),
            "key_action_data": json.dumps(event_item.get('keyActionData', {}), ensure_ascii=False),
            "online_data": json.dumps(event_item.get('onlineData', {}), ensure_ascii=False),
            "payment_data": json.dumps(event_item.get('paymentData', {}), ensure_ascii=False),
            "lv_change_data": json.dumps(event_item.get('lvChangeData', {}), ensure_ascii=False),
            "use_gold_data": json.dumps(event_item.get('useGoldData', {}), ensure_ascii=False),
            "ts": event_item.get('ts', 0),
        }
        e_items = sorted(e.items(), key=lambda x: x[0])
        log_data['event'] = '{%s}' % ', '.join(['"%s": "%s"' % (k, v) for k, v in e_items])
        items = sorted(log_data.items(), key=lambda x: x[0])
        hdfs_logger.info('{%s}' % ', '.join(['"%s": "%s"' % (k, v) if k != 'event' else '"%s": %s' % (k, v) for k, v in items]))

