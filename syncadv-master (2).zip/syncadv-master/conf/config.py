# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技

import configparser
import os
import sys
import traceback

# selection 链接的数据库配置名， keys 配置中键
def get_config(section, key,conf ="source" ):
    config = configparser.ConfigParser()
    #path = os.path.dirname(os.path.dirname(__file__)) + "/conf/" + conf + ".conf"
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"conf","{conf}.conf".format_map({'conf':conf}))
    config.read(path,encoding='utf-8')
    try:
        p = config.get(section, key)
        return p
    except BaseException as e:
        traceback.print_exc()

def set_config_value(conf, section, key, value):
    config = configparser.ConfigParser()
    # path = os.path.dirname(os.path.dirname(__file__)) + "/conf/" + conf + ".conf"
    path = os.path.join(os.path.dirname(os.path.dirname(__file__)),"conf","{conf}.conf".format_map({conf:conf}))
    config.read(path)
    try:
        config.set(section, key, str(value))
        fh = open(path, 'w')
        config.write(fh)  # 把要修改的节点的内容写到文件中
        fh.close()
    except BaseException as e:
        traceback.print_exc()
