# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
import json
import math

import bson
import requests

from common.common import get_obj_md5, get_current_timestamp
from dataBase import dataBase
from urllib import  parse

def copy():
    print("sdk mongo to ")
    pass


# 微信上报
def rerpotwx(app_type, click_id, conv_time, muid, sign_key, appid, adv_id, conv_type):
    app_type = str(app_type).upper()
    kl = "app_type=%s&click_id=%s&client_ip=&conv_time=%d&muid=%s&sign_key=%s"%(app_type, click_id,conv_time, muid, sign_key)
    mstr = get_obj_md5(kl)
    send_url = "https://t.gdt.qq.com/conv/app/%s/conv"%appid
    send_b = "click_id=%s&muid=%s&appid=%s&conv_time=%d&client_ip=&encstr=%s&encver=1.0&advertiser_id=%s&app_type=%s&conv_type=%s"%(click_id, muid, appid, conv_time, mstr, adv_id, app_type, conv_type)
    dat = parse.urlparse(send_b)
    zd = parse.parse_qs(dat.path)
    res = requests.post(send_url, data=zd).json()
    print("wxreport=====", res)
    if res['ret'] == 0 :
        return True
    return False

# 百度shangbao
def get_akey(pg,pid,rid):
    dt = pg.query("select * from ty_dsp_trace where pid = '%s' and rid = '%s'"%(pid,rid))
    if len(dt) ==1:
        ak = dt[0]['akey']
        return ak

# 后偶去微信的值 select app_id,encrypt_key,sign_key,pid,advertiser_id as rid from ty_dsp_trace where type = 2
#select * from ty_dsp_trace where type = 2  pid = and advertiser_id =
def get_wx_key(pg,pid,rid):
    dt = pg.query("select * from ty_dsp_trace where pid = '%s' and advertiser_id = '%s'" % (pid, rid))
    if len(dt) == 1:
        ak = dt[0]['sign_key']
        return ak

def baidu(db,mg):
    print(mg["backurl"])
    backurl = str(mg["backurl"]).replace("{{ATYPE}}", "activate").replace("{{AVALUE}}", "0")
    akey = get_akey(db.pg, mg["gameid"], mg["rid"])

    sign = get_obj_md5("%s%s" % (backurl, akey))
    back_url = "%s&sign=%s" % (backurl, sign)
    dta = requests.get(back_url)
    data = dta.json()
    print("百度report=>",data)
    db.new_mg["adtdata"].update_one({"_id":mg["_id"]},{'$set':{"status":1}})


## 修正微信投放数据
def Rback(mg,new_mgod):
    nuym = mg["device_info_log"].find({}).count()
    print("总数据=》",nuym)
    pages = math.ceil(nuym / 10000)
    for item in range(pages):
        # dt = mg["device_info_log"].find().limit(10)
        dt = mg["device_info_log"].find({"ip":{"$ne":""}}).skip(item * 10000).limit(10000)

        for info in dt:
            data = dict(info)
            if data.get("ip") is not None:
                dta = new_mgod["adtdata"].find(
                    {"gameid": "%d" % data["pid"], "ip": data["ip"]}).count()
                if dta >= 1:
                    print("重复数据=》", data)
                    new_mgod["adtdata"].update_one(
                        {"gameid": "%d" % data["pid"], "ip": data["ip"], "status": -1},{'$set':{"status":1}})

    pass

# 清除重复的点击数据
def clearncopy(mg,pid,start,end):
    dt = mg.new_mg["adtdata"].find({"gameid":str(pid),"clicktime":{"$gte":start,"$lt":end}})
    for info in dt:
        data = dict(info)

        dta = mg.new_mg["adtdata"].find({"gameid": "%d" % pid,"muid":data["muid"],"business_id":data["business_id"]}).count()
        if dta >1:
            print("重复数据=》",data)
            mg.new_mg["adtdata"].delete_one({"gameid": "%d" % pid,"muid":data["muid"],"business_id":data["business_id"],"status":-1})


if __name__ == "__main__":
    with dataBase(mongo_name="newdsp", db_name="dsp") as db:
        #Rback(db.mg,db.new_mg)

        #clearncopy(db,2252,1563624000,1563724800)
        # count = db.new_mg["adtdata"].find({}).sort('clicktime',-1).limit(1)
        # for item in count:
        #     print(item)
        #     print("dsp adt count=>",item['clicktime'])
        #     lost = db.mg['adtdata'].find({'clicktime':{'$gte':item['clicktime']/1000}})
        #     print("morethan=>",lost)
        #     for cv in lost:
        #         data = dict(cv)
        #         print(data)
        #         # db.new_mg["adtdata"].find_and_modify({'_id':bson.ObjectId(data['_id'])},data,True)
        #         # #db.new_mg["adtdata"].find_one_and_update({'_id':data['_id']},data)
        #         db.new_mg["adtdata"].save(data)
        #
        # 苍穹传之武道乾坤 3004 63081
        # 苍穹传之一念仙缘  3009 62133
        # 武道神尊之天剑问情 2884 71453



        cotent = db.pg.query("select * from ty_device_active_new where pid= 3093 and ts >= '2019-10-16 11:00:50' ")

        # cotent = db.pg.query('''
        #         #     SELECT T
        #         #         .* ,ac.muid
        #         #     FROM
        #         #         ty_device_active_new AS ac
        #         #         INNER JOIN ty_user_meta_data AS tu ON ac.pid = tu.pid
        #         #         AND ac.deviceid = tu.imei
        #         #         INNER JOIN ty_user_orders AS T ON tu.ucid = T.ucid
        #         #     WHERE
        #         #          ac.active_date >= 20190710
        #         # ''')

        doc = db.new_mg["adtdata"]
        for item in cotent:
            rid = item['rid']
            pid = item['pid']
            muid= item['muid']

            dt = doc.find({'gameid':"%s"%pid,'muid':"%s"%muid})

            for adt in dt:
                channel = adt["channel"]
                # # 百度上报
        #         if channel == 7:
        #             baidu(db, adt)

                # # 今日头条
                # if channel == 1:
                #     jr =requests.get(adt['backurl'])
                #     print("jr=>",jr)
                #

                # updateArgs = {'$set': {'status': 1}}
                # if channel == 20:
                #     jr =requests.get(adt['backurl'])
                #     print("快手=>",jr.content,muid)
                #     doc.update({'gameid':"%s"%pid,'muid':"%s"%muid,"business_id":7},updateArgs)

                # # 微信
                if channel == 17 :
                    print(adt["muid"])
                    sign_key = get_wx_key(db.pg,adt["gameid"],adt["rid"])
                    conv_time = int(get_current_timestamp() /1000)
                    sy = rerpotwx(adt["apptype"], adt["clickid"], conv_time, muid, sign_key, adt["appid"], adt["uid"], "MOBILEAPP_ACTIVITE")
                    if sy :
                        doc.update_one(
                            {"gameid": adt["gameid"], "muid": adt["muid"], "status": -1}, {'$set': {"status": 1}})
                    pass


        # cotent_ip = db.pg.query("select regip,pid from ucusers where regdate >= 1558454400")
        # for item in cotent_ip:
        #     pid = item['pid']
        #     ip= item['regip']
        #     dt = db.mg['adtdata'].find({'ip':"%s"%ip,'gameid':"%s"%pid})
        #
        #     for adt in dt:
        #         channel = adt["channel"]
        #         # # 百度上报
        #         if channel == 7:
        #             baidu(db, adt)
