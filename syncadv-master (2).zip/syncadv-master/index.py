# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# desc 抓取dataeye的消耗数据，格式化入库，同步锋红单价获取真实的消耗的金额
import datetime
import os
import sys

import aiohttp
from  dataBase import dataBase
import asyncio

def get_pageid(db,plan_name):
        dat = db.pg.query("select id from ty_page where name = '{plan_name}'".format(plan_name = plan_name))
        if dat is not None and len(dat) >0:
            return dat[0]['id']
        return 0

# 抓取账号消耗
business_dict = {'af':0,'yy':5,'tt':7,'tw':6,'zx':9,'zy':8}

# 上线否
is_online = False
w
async def get_page_exists(db):
    async with aiohttp.request('GET', COST_URL) as r:
        data = await r.json()
        cost_data = data['content']['detail']
        for item in cost_data:
            save_data = {}
            if not dict(item).__contains__('medium'):
                print("error_msg:",item)
                continue

            save_data['create_date'] = str(item["currentDate"]).replace('-','')
            save_data['medium']     = item["medium"] if dict(item).__contains__('medium') else ''                  # 投放的媒体信息
            save_data['account']    = item["account"]                   # 抓取的账号信息
            save_data['adt_name']   = item["planName"]                  # 原始的投放
            save_data['show_num']   = item["exposures"]                 # 展示数据
            save_data['click_num']  = item["clicks"]                    # 广告点击的数据
            save_data['plan_id']    = item["mediumPlanId"]              # 媒体广告计划ID
            save_data['total_cost'] = item["totalCost"]                 # 今日总消耗虚拟币的消耗

            page_name_num = str(save_data['adt_name']).split("-")
            save_data['page_name'] = page_name_num[1] if len(page_name_num) > 1 else ''
            save_data['page_id'] = get_pageid(db, save_data['page_name']) if save_data['page_name'] != '' else 0
            save_data['business_id'] = business_dict.get(page_name_num[0], 0)
            danjia = get_account_money(db, save_data['account'])
            save_data['money_rmb'] = float(save_data['total_cost']) * danjia if danjia is not None else 0
            print("save_data",save_data)
            # save
            save_data_func(db,save_data)

# 获取当前账号已经存在
def get_data_count(db,crawl_date,plan_id):
    run_sql = "select count(*) as total from ty_dataeye_sync where create_date = {create_date} and plan_id = {paln_id}".format(create_date = crawl_date,paln_id = plan_id)
    dt = db.pg.query(run_sql)
    if dt is not None and len(dt) > 0:
        num = dt[0]['total']
        if num > 0:
            return True
    return False

# 获取页面的账户信息
def get_data_page(db,page_id):

    run_sql = '''
        select page.id, page.name, c.name as media_name, ag.name as page_group_name, apg.id as agent_id, apg.name as agent_name, apg.nickname as agent_nickname, apa.username as account_name, 
        admin.username AS admin_username,
            create_admin.username AS create_admin_username, adv_business.name AS adv_business_name
        from af_page as page 
        left join af_adv_channel as c on c.id = page.adv_id
        LEFT JOIN af_adv_business AS adv_business ON adv_business.id = page.business_id
        LEFT JOIN  af_page_group as ag on page.group_id = ag.id
        LEFT JOIN af_page_account_agents as pa on pa.account_id = ag.account_id
        left join af_page_account as apa on pa.account_id = apa.id 
        left join af_page_agents as apg on pa.agent_id = apg.id
        
        LEFT JOIN anfeng_{op}.af_adminAccount AS admin ON admin.uid = page.admin_uid
        LEFT JOIN anfeng_{op}.af_adminAccount AS create_admin ON create_admin.uid = page.create_admin_uid
        where page.id = {page_id}
    '''.format(page_id=page_id,op='tui' if not is_online else 'operate')

    # 数据展示

    dat = db.adv_mysql.query(run_sql)
    if len(dat) > 0:
        return dict(dat[0])
    else:
        return None

# save data 日期 媒体计划ID 唯一键
def save_data_func(db,data):
    ishad = get_data_count(db,data['create_date'],data['plan_id'])

    data['agent_id'] = 0
    data['page_group_name'] = ''
    data['agent_name'] = ''
    data['agent_nickname'] = ''
    data['admin_username'] = ''
    data['create_admin_username'] = ''

    if data['page_id'] >0 :
        dat = get_data_page(db,data['page_id'])
        if dat is not None:
            data['agent_id'] = dat.get('agent_id', 0)
            data['page_group_name'] = dat.get('page_group_name', '')
            data['agent_name'] = dat.get('agent_name', '')
            data['agent_nickname'] = dat.get('agent_nickname', '')
            data['admin_username'] = dat.get('admin_username', '')
            data['create_admin_username'] = dat.get('create_admin_username', '')

    if not ishad :
        # 写入
        insert_sql = '''insert into ty_dataeye_sync 
                        (create_date,medium,account,adt_name,show_num,click_num,plan_id,total_cost,page_name,page_id,business_id,money_rmb,agent_id,page_group_name,
                        agent_name,agent_nickname,admin_username,create_admin_username) 
                        values
                        ({create_date},'{medium}','{account}','{adt_name}',{show_num},{click_num},{plan_id},{total_cost},'{page_name}',{page_id},{business_id},
                        {money_rmb},{agent_id},'{page_group_name}','{agent_name}','{agent_nickname}','{admin_username}','{create_admin_username}')
                    '''.format(
                          create_date   = data['create_date'],
                          medium        = data['medium'],
                          account       = data['account'],
                          adt_name      = data['adt_name'],
                          show_num      = data['show_num'],
                          click_num     = data['click_num'],
                          plan_id       = data['plan_id'],
                          total_cost    = data['total_cost'],
                          page_name     = data['page_name'],
                          page_id       = data['page_id'],
                          business_id   = data['business_id'],
                          money_rmb     = data['money_rmb'],
                          agent_id      = data['agent_id'],
                          page_group_name  = data['page_group_name'],
                          agent_name = data['agent_name'],
                          agent_nickname = data['agent_nickname'],
                          admin_username = data['admin_username'],
                          create_admin_username = data['create_admin_username']
                    )
        db.pg.execute(insert_sql)
        update_other_business(db, insert_sql)
    else:
        # 更新
        update_sql = '''update ty_dataeye_sync set total_cost = {total_cost},money_rmb = {money_rmb} 
                where create_date = {create_date} and plan_id = {plan_id} '''.format(
                    total_cost=data['total_cost'],
                    money_rmb       =data['money_rmb'],
                    create_date     =data['create_date'],
                    plan_id         =data['plan_id']
                )
        db.pg.execute(update_sql)
        update_other_business(db,update_sql)

def get_account_money(db,account):
        dt = db.adv_mysql.query("select money_balance / vc_balance  as s_money from af_page_agent_account where account = '{account}'".format(account=account))
        if len(dt) >0 and dt[0][0] is not None:
            money = dt[0][0]
            return float(money)
        return 0

# 更新 团玩 团团
def update_other_business(db,sql):
    for index in range(5,10):
        dblink = "host=localhost port=3002 dbname=tianyan_{business_id} user=tianyan password=Wuaf!@#comTydaHan52".format(business_id=index)
        db_sql = "select dblink('{db_link}'，'{sql}')".format(db_link = dblink, sql = sql)
        db.pg.execute(db_sql)

# 抓取账号余额
async def get_account_balance(db):
    print("同步余额")
  
def show_detail(db):
    print("1223")

def getYesterday():
    today=datetime.date.today()
    oneday=datetime.timedelta(days=1)
    yesterday=today-oneday
    return yesterday

header_dict = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko'}
COST_URL = "http://adt.dataeye.com/ad/plandata/query.do?userName=qiubaohua@anfan.com&password=6316877&statDate="
BALANCE_URL = "http://adt.dataeye.com/ad/balanceApi/list.do?userName=qiubaohua@anfan.com&password=6316877&statDate="

if __name__ == "__main__":
    if len(sys.argv) > 1 :
        yesterday = getYesterday().strftime("%Y-%m-%d")
        COST_URL = COST_URL+yesterday
        print("yseterday=>",COST_URL)

    with dataBase() as db:
        takes = [get_page_exists(db=db)]  # 合并
        db.loop.run_until_complete(asyncio.wait(takes))  # 等待执行完成
