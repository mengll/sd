# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
import datetime
import sys
import time
import asyncio
from dataBase import dataBase

from marketing.jrtt.sync import SyncDat

pages = {}

def get_timestamp_day(day,time_stmp =time.time()):
    day_temp = time.strftime("%Y-%m-%d",time.localtime(int(time_stmp)))
    day_temp = datetime.datetime.strptime(day_temp,"%Y-%m-%d")
    back = day_temp + datetime.timedelta(days=day)
    print(back)
    return int(back.timestamp())


def initpage(db):
    start_ts = get_timestamp_day(-100)
    dat = db.query("select id,name from af_page where status = 'normal' and create_time > {start_ts}".format(start_ts=start_ts))
    for item in dat:
        pages[item["name"]] = item["id"]


if __name__ == "__main__":
    l = sys.argv[1]
    print("start",l)
    with dataBase(mongo_name="mongodb_sdk",db_name="dsp") as db:
        initpage(db.adv_mysql)
        sync = SyncDat(db.pg, db.adv_mysql, db.mg, pages)
        sync.parseDaylyStat()