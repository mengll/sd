import math
import random

rand = [8, 9, 2, 3, 6, 1, 4, 5, 7, 10]
new  = [9, 2, 3, 1, 4, 7, 10]
def create_random():
    for i in range(1,4,1):
        index = random.randint(0, 9-i)
        rand.pop(index)

# 面向接口的编程
if __name__ == "__main__":
    create_random()
    new_list = rand
    pass