from advbase import advBase
from common import common
from common.common import get_bf_day

if __name__ == "__main__":

    with advBase(mongo_name="newdsp", db_name="dsp") as db:
        dsp_mongo = db.new_mg["wx_gdt"]

        # 获取最大rid
        # max_id_data = db.new_mg["wx_gdt"].find({}).sort("id:-1").limit(1)
        # num = max_id_data.count()
        # start = dict(max_id_data[0])["id"] if num > 0 else 1
        # 获取最大的计划数据匹配
        start_ts = get_bf_day(1)
        table = ["af_media_gdt_project","af_media_wxmp_project"]
        for name in table:
            dts = db.anfeng_adv.query(r"select * from {name} where update_ts >= {start_ts}  or create_ts >= {start_ts}".format(name=name,start_ts=start_ts))
            name_list = []

            for item in dts:
                # 计划id
                plan_id = item["platform_uuid"]
                project_name = item["name"]
                dt = str(project_name).split("-",2)
                if len(dt) <= 2:
                    print("更细",item["name"])
                    continue
                name_list.append("'{name}'".format(name=dt[1]))
                #todo 待优化
                #db.new_mg["gdtrid"].insert()
                if dt[0] == "af":
                    names = ",".join(name_list)
                    page_list = db.anfeng_adv.query("select * from af_page where name in({name_list})".format(name_list=names))
                    for page in page_list:
                        num = dsp_mongo.find({"adid":plan_id}).count()
                        print(plan_id,num,common.get_current_datetime())
                        if num >0:
                            dsp_mongo.update({"adid":plan_id},{"id":item["id"],"adid":plan_id,"name":project_name,"rid":page["channel_id"],"pid":page["apk_id"],"ts":common.get_current_datetime()},upsert=True)
                        else:
                            print("写入")
                            dsp_mongo.insert({"id":item["id"],"adid":plan_id,"name":project_name,"rid":page["channel_id"],"pid":page["apk_id"],"createts":common.get_current_datetime()})
                    name_list = []

            tt = db.tuantuan_adv.query(
                r"select * from {name} where update_ts >= {start_ts}  or create_ts >= {start_ts}".format(name=name,
                                                                                                         start_ts=start_ts))
            name_list = []
            for item in tt:
                # 计划id
                plan_id = item["platform_uuid"]
                project_name = item["name"]
                dtt = str(project_name).split("-", 2)
                if len(dtt) <= 2:
                    print("更细", item["name"])
                    continue

                if dtt[0] == "tt":
                    names = ",".join(name_list)
                    page_list_tt = db.tuantuan_adv.query("select * from af_page where name in({name_list})".format(name_list=names))
                    for page in page_list_tt:
                        num = dsp_mongo.find({"adid": plan_id}).count()
                        if num > 0:
                            dsp_mongo.update({"adid": plan_id}, {"id": item["id"], "adid": plan_id, "name": project_name,
                                                                 "rid": page["channel_id"], "pid": page["apk_id"]},
                                             upsert=True)
                        else:
                            print("写入")
                            dsp_mongo.insert(
                                {"id": item["id"], "adid": plan_id, "name": project_name, "rid": page["channel_id"],
                                 "pid": page["apk_id"]})
