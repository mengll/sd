import datetime
import time

from adt import initpage
from dataBase import dataBase
from marketing.jrtt.balance import Balance

pages = {}

def get_timestamp_day(day,time_stmp =time.time()):
    day_temp = time.strftime("%Y-%m-%d",time.localtime(int(time_stmp)))
    day_temp = datetime.datetime.strptime(day_temp,"%Y-%m-%d")
    back = day_temp + datetime.timedelta(days=day)
    print(back)
    return int(back.timestamp())

def initpage(db):
    start_ts = get_timestamp_day(-100)
    dat = db.query("select id,name from af_page where status = 'normal' and create_time > {start_ts}".format(start_ts=start_ts))
    for item in dat:
        pages[item["name"]] = item["id"]

if __name__ == "__main__":
    with dataBase(mongo_name="mongodb_sdk", db_name="dsp") as db:
        initpage(db.adv_mysql)

        # 广告创意与素材关联
        # td = JrttCreative(db.pg,db.adv_mysql,db.mg,pages)
        # td.ParseCreative()

        balance = Balance(db.pg,db.adv_mysql,db.mg,pages)
        balance.ParseBalance()