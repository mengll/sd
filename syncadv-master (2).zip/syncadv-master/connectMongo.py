# _*_ coding: utf8 _*_
# 数据库相关的连接
# 异步循序的开启关闭
import asyncio

from kafka import KafkaConsumer

from common.common import get_current_datetime
from common.config import Config
from common.database import pg_client, mysql_client
from common.mongo import mongodb


class dataBase(object):
    def __init__(self,mongo_name="mongodb_sdk",db_name="adtdata"):

        # dsp 新MongoDB库
        mgo_new = mongodb()
        self.newmongo = mgo_new.mongo_init("newdsp")
        self.new_mg = self.newmongo[r'%s' % db_name]

        self.loop = asyncio.get_event_loop()


    def __enter__(self):
        print("开始同步：{start}".format(start=get_current_datetime()))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.loop.close()
        print("数据同步完成:{end}".format(end=get_current_datetime()))
        pass
