# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技

from common.common import get_current_date, get_input_timestamp
from dataBase import dataBase
def copy():
    print("sdk mongo to ")
    pass

if __name__ == "__main__":
    with dataBase(mongo_name="mongodb_sdk", db_name="dsp") as db:
        current_date = get_current_date()
        new_mg = db.new_mg["adt_dailyreports"].find({"platform": 1, "date": current_date})
        business_ids = {"af": 0, "tt": 7, "tw": 6, "zy": 8, "zx": 9, "yy": 5}

        data = db.pg.query("select * from ty_device_active_new where pid = 3181 and rid = 64549 and active_date = 20190426")
        for item in data :
            one = db.new_mg["adtdata"].find({"gameid":str(item["pid"]),"muid":item["muid"]})
            if one.count() == 0:
                print("=============>",item["pid"],item["rid"],item["muid"])

            for im in one:
                if get_input_timestamp(im["clicktime"]) != 20190426:
                    print("not--dat=>",get_input_timestamp(im["clicktime"]),im["gameid"],im["muid"])
        #     print(item)
        #     ad_name = str(item["planname"]).split("-",2)
        #
        #     print("同步广告计划=》",ad_name)
        #     business_id = business_ids.get(ad_name[0],0)
        #     dates = str(item["date"]).replace("-","")
        #     plan_name = ad_name[1] if len(ad_name) > 1 else ''
        #
        #     sql = '''
        #     INSERT INTO ty_dataeye_cost (create_date,total_cost,view_num,click_nums,medium,account,plan_name,medium_plan_id,business_id,adt_name)
        #         VALUES
        #          ({create_date},{total_cost},{view_num},{click_nums},'{medium}','{account}','{plan_name}','{medium_plan_id}',{business_id},'{adt_name}')
        #         on CONFLICT (create_date,medium_plan_id,account) DO UPDATE set total_cost = EXCLUDED.total_cost,view_num=EXCLUDED.view_num,click_nums=EXCLUDED.click_nums,adt_name=EXCLUDED.adt_name,
        #         plan_name=EXCLUDED.plan_name
        #     '''.format(create_date=int(dates),total_cost=item["cost"],view_num=item["impression"],click_nums=item["click"],
        #                medium="今日头条",account=item["accountname"],plan_name=plan_name,medium_plan_id=int(item["campaignid"]),business_id=business_id,adt_name=item["planname"])
        #
        #     db.pg.execute(sql)
        #
        # # 数值的方式现在内容

        #