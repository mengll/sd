# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
import json

from common.common import get_obj_md5
from common.common_old import get_timestamp_day

DEFAULT_FAILED    = -1
PLAN_UPDATE_KEY   = " ON CONFLICT (channel_id, muid, plan_id, creative_id) do update set status = excluded.status "

from dataBase import dataBase

def sync_ocpc(mg,my):
    mg_db = mg["ocpc_click"]
    start_time = get_timestamp_day(-1)  # 当前时间的前一天重新跑
    dt = mg_db.find({"gameid":'3097',"rid":'89089',"clicktime":{"$gte":1558195200,"$lt":1558368000}})

    data_list = []
    for item in dt:
        data_list.append("({pid},{rid},'{muid}','{mac}',{ts})".format(pid=item['gameid'],rid=item['rid'],muid=item['muid'],mac=item['mac'],ts=item['clicktime']))

    if len(data_list):
        run_sql = "insert into ocpc_click (pid,rid,muid,mac,ts) values "+','.join(data_list)
        print(run_sql)
        my.execute(run_sql)



# sync data to 246
def sync_sdk(pg,my):
    #my.execute("delete * from sdk_active")
    dat = pg.query("select * from ty_device_active_new_bak")
    data_list = []
    for item in dat:
        mac = get_obj_md5(str(item["mac"]).replace(":",""))
        data_list.append("({pid},{rid},'{muid}',{date},'{mac}','{brand}')".format(pid=item["pid"],rid=item["rid"],muid=item["muid"],date=item["active_date"],mac=mac,brand=item["brand"]))

    if len(data_list):
        run_sql = "insert into sdk_active (pid,rid,muid,date,mac,brand) values " + ','.join(data_list)
        my.execute(run_sql)


# 同步激活数据
def sync_active(pg,my):
    dat = pg.query("select * from ty_device_active_new where pid ='{pid}' and active_date >= {ac}".format(pid=3097,ac=20190510))
    data_list = []
    for item in dat:
        data_list.append("({pid},{rid},'{muid}',{date})".format(pid=item["pid"], rid=item["rid"],
                                                                                  muid=item["muid"],
                                                                                  date=item["active_date"]))
    if len(data_list):
        run_sql = "insert into active_device (pid,rid,muid,active_date) values " + ','.join(data_list)
        my.execute(run_sql)

if __name__ == '__main__':
    with dataBase(mongo_name="newdsp",db_name="dsp") as db:
        sync_active(db.pg,db.localmysql)
        sync_ocpc(db.mg,db.localmysql)
        #sync_sdk(db.pg,db.localmysql)
        # 2159 37769