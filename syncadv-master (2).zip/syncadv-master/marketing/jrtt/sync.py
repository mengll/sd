# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
# desc 解析数据内
import bson

from common.common import get_current_date, get_yesterday


class SyncDat():
    def __init__(self, pg, adv, mg, pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg
        self.bs_id = {'af': 0, "yy": 5, "tt": 7, "tw": 6, "zy": 8, "zx": 9}
        pass

    # 解析广告计划的点击，消耗
    def parseDayReport(self):
        mg_db = self.mg["adt_dailyreports"]
        dt = get_current_date()
        print("同步数据日期:",dt)
        dat = mg_db.find({"date":"%s"%dt})
        for obj in dat:
            plan = str(obj["planname"]).split("-", 2)
            bn = self.bs_id.__contains__(plan[0])
            business_id = self.bs_id[plan[0]] if bn else -1  # 解析当前公司
            adt_name = plan[1] if len(plan) == 3 else ''
            obj["cost"] = obj["cost"] / 100  # 抓取的消耗为分，需要转化成元
            obj["businessid"] = business_id  # 属于哪个公司
            obj["adtname"] = adt_name  # 锋红的计划名称

            if obj["cost"] > 0:
                insert_sql = '''INSERT INTO ty_dataeye_cost 
                               (create_date,total_cost,view_num,click_nums,medium,account,plan_name,medium_plan_id,business_id,adt_name) 
                               VALUES ('{create_date}',{total_cost},{view_num},{click_nums},'{medium}','{account}','{plan_name}',{ad_id},{business_id},'{adt_name}') 
                               on CONFLICT (create_date,medium_plan_id,account) 
                               DO UPDATE set total_cost = EXCLUDED.total_cost,view_num=EXCLUDED.view_num,click_nums=EXCLUDED.click_nums,adt_name=EXCLUDED.adt_name,
                               plan_name=EXCLUDED.plan_name'''.format(
                    create_date=obj["date"],
                    total_cost=obj["cost"],
                    view_num=obj["impression"],
                    click_nums=obj["click"],
                    medium="今日头条",
                    account=obj["accountname"],
                    plan_name=obj["adtname"],  # 锋红计划名称
                    ad_id=obj["adid"],
                    business_id=obj["businessid"],
                    adt_name=obj["planname"]  # 媒体投放名称
                )
                self.pg.execute(insert_sql)

    # 同步昨日余额数据(获取余额的数据更新)
    def parseDaylyStat(self):
        td = get_current_date()
        yd = get_yesterday()
        mgc = self.mg["adt_daily_stat"]
        dt = mgc.find({"date":yd,"platform":1,"balance":{"$gt":0}}).forEach(bson.Code('''
            function(u){ 
                   res = db.adt_account.findOne({"id":u.advertiserid})
                   u.email = res.email
                   u.yesterday_balance = u.balance
                   balance = db.adt_balance.findOne({"advertiser_id":u.advertiserid,"date":"2019-02-20"})
                   u.balance = balance.balance
                   print(u)
            }
        '''))

        # 打印昨日余额
        for item in dt:
            print("昨日余额=>",item)
        pass

    # 获取落地页page_id
    def getPageId(self,obj):
        planname = obj["adtname"]
        businessid = obj["businessid"]
        sql = "select id from ty_page where name = ''%s''"%planname
        dblink = "host=localhost port=3002 dbname=tianyan_{business_id} user=tianyan password=Wuaf!@#comTydaHan52".format(
            business_id=businessid)
        db_sql = "select * from dblink('{db_link}','{sql}') t (id INTEGER)".format(db_link=dblink, sql=sql)
        dt = self.pg.query(db_sql)

        page_id = -1
        if len(dt) >0:
            page_id =  dt[0][0] if dt[0] is not None else -1
        up_sql = "update ty_webpage_day set show_num = %d , click_num = %d , cost = %f where page_id= %d  and add_date = %d"% \
                 (obj["impression"],obj["click"],obj["cost"],page_id,20190219)
        update_sql = "select dblink('{db_link}','{up_sql}')".format(db_link=dblink, up_sql=up_sql)
        print(update_sql)


    # 天眼page
    def getTypage(self,obj):
        planname = obj["adtname"]
        sql = "select id from ty_page where name = '%s'" % planname
        dt = self.pg.query(sql)

        page_id = -1
        if len(dt) > 0:
            page_id = dt[0][0] if dt[0] is not None else -1