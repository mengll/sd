# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
# desc 解析今日头条广告计划
import json

from kafka import KafkaConsumer
class PlanAds():
    def __init__(self, pg, adv, mg, pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg

        # kafka
        self.kafka = KafkaConsumer(bootstrap_servers="172.18.254.24:9092,172.18.254.23:9092,172.18.253.195:9092",
                                   group_id='adt',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
        self.bs_id = {'af': 0, "yy": 5, "tt": 7, "tw": 6, "zy": 8, "zx": 9}

    def ParsePlanAds(self):
        mg_db = self.mg["adt_plan_ads"]

        self.kafka.subscribe(["adt_plan_ads"])
        for msg in self.kafka:
            cont = msg.value.decode('utf-8')
            obj = json.loads(cont, encoding="utf-8")
            mg_db.update(
                {"adid": obj["adid"],"campaignid":obj["campaignid"],"advertiserid":obj["advertiserid"],"date":obj["date"]}
                , obj, upsert=True)

