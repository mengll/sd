# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
# desc 账号日流水
import json

from kafka import KafkaConsumer

class DailiStat():
    def __init__(self, pg, adv, mg, pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg

        # kafka
        self.kafka = KafkaConsumer(bootstrap_servers="172.18.254.24:9092,172.18.254.23:9092,172.18.253.195:9092",
                                   group_id='adt',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
        self.bs_id = {'af': 0, "yy": 5, "tt": 7, "tw": 6, "zy": 8, "zx": 9}

    def ParseDailyStat(self):
        mg_db = self.mg["adt_daily_stat"]
        self.kafka.subscribe(["adt_daily_stat"])
        for msg in self.kafka:
            cont = msg.value.decode('utf-8')
            obj = json.loads(cont, encoding="utf-8")

            mg_db.update(
                {"Platform": obj["Platform"], "Advertiserid": obj["advertiserid"], "Date": obj["Date"]}
                , obj, upsert=True)