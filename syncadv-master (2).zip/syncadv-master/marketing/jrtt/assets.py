# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
# desc 解析图片库
import asyncio
import json

from kafka import KafkaConsumer
class Assets():
    def __init__(self, pg, adv, mg, pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg

        # kafka
        self.kafka = KafkaConsumer(bootstrap_servers="172.18.254.24:9092,172.18.254.23:9092,172.18.253.195:9092",
                                   group_id='adt',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
        self.bs_id = {'af': 0, "yy": 5, "tt": 7, "tw": 6, "zy": 8, "zx": 9}
        self.data = []

    def ParseAssets(self):
        mg_db = self.mg["adt_assets"]
        self.kafka.subscribe(["adt_image","adt_video"])
        for msg in self.kafka:
            cont = msg.value.decode('utf-8')
            obj = json.loads(cont, encoding="utf-8")
            print("素材信息=>",obj)
            mg_db.update({"signature": obj["signature"]}, obj, upsert=True)