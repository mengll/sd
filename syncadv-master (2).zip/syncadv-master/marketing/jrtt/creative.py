# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
import asyncio
import json

from kafka import KafkaConsumer

from common.common_old import convert_daystr_day


class  JrttCreative():
    def __init__(self,pg,adv,mg,pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg
        self.data = []
        #kafka
        self.kafka = KafkaConsumer(bootstrap_servers="172.18.254.24:9092,172.18.254.23:9092,172.18.253.195:9092",
                                   group_id='adt',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
        self.bs_id = {'af':0,"yy":5,"tt":7,"tw":6,"zy":8,"zx":9}

    def ParseCreative(self):
        print("获取广告计划")

        self.kafka.subscribe(["adt_adcreative"])
        for msg in self.kafka:
            cont = msg.value.decode('utf-8')
            obj = json.loads(cont,encoding="utf-8")
            ad_id = obj["ad_id"] # 广告计划
            adv_id = obj["advertiser_id"] # 广告账号
            creative_id = obj["creative_id"] #广告创意id

            img_id = obj["image_id"]      # 图片id
            title = obj["title"]          # 创意标题
            video_id = obj["video_id"]    # 视频id
            metarials = obj["metarials"]  # 素材文件

            dat={}
            dat["platform"] = 1
            dat["ad_id"] = ad_id  #
            dat["advertiser_id"] = adv_id
            dat['creative_id'] = creative_id
            dat['image_id'] = img_id
            dat['video_id'] = video_id
            dat['title'] = title
            dat['type'] = 0
            if dat['video_id'] != '':
                dat['type'] = 1

            if len(metarials) > 0:
                for item in metarials:
                    sub_title = item["title"]
                    image_id = item["image_id"]
                    video_id = item["video_id"]
                    if sub_title is not None:
                        if image_id is not None:
                            print("sub-img=>", image_id,"\n")
                            dat['image_id'] = img_id
                            dat['title'] = sub_title
                            self.saveData(dat)
                        if video_id is not None:
                            dat['video_id'] = video_id
                            dat['title'] = sub_title
                            dat['type'] = 1
                            self.saveData(dat)

            if img_id is not None or video_id is not None:
                self.saveData(dat)

        else:
            print("解析kafka完毕")

    #保存相关的创意素材信息
    def saveData(self,obj):
        print("创意数据===》",obj)
        mg_db = self.mg["adt_adcreative"]
        mg_db.update(
            {"platform": obj["platform"], "creative_id": obj["creative_id"], "ad_id": obj["ad_id"], "type":obj['type'],"image_id":obj["image_id"],
             "video_id":obj["video_id"]}
            , obj, upsert=True)