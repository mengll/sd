# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 marketing
# desc 日消耗数据
#
import json

from kafka import KafkaConsumer

class JrttDayliReport():
    def __init__(self,pg,adv,mg,pages):
        self.pg = pg
        self.adv = adv
        self.pages = pages
        self.mg = mg

        #kafka
        self.kafka = KafkaConsumer(bootstrap_servers="172.18.254.24:9092,172.18.254.23:9092,172.18.253.195:9092",
                                   group_id='adt',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
        self.bs_id = {'af':0,"yy":5,"tt":7,"tw":6,"zy":8,"zx":9}

    def ParseDayliReport(self):
        print("广告计划日报")
        mg_db = self.mg["adt_dailyreports"]

        self.kafka.subscribe(["adt_dailyreports"])
        for msg in self.kafka:
            cont = msg.value.decode('utf-8')
            obj = json.loads(cont,encoding="utf-8")
            plan = str(obj["PlanName"]).split("-",2)
            print(plan)
            bn = self.bs_id.__contains__(plan[0])
            business_id = self.bs_id[plan[0]] if bn else -1 # 解析当前公司
            adt_name    = plan[1] if len(plan) == 3 else ''
            obj["Cost"] = obj["Cost"] / 100  # 抓取的消耗为分，需要转化成元
            obj["BusinessId"] = business_id  # 属于哪个公司
            obj["Adtname"] = adt_name        # 锋红的计划名称
            mg_db.update({"Platform":obj["Platform"],"CampaignId":obj["CampaignId"],"AdId":obj["AdId"],"Date":obj["Date"],"PlanName":obj["PlanName"]}
            ,obj,upsert=True)

            if obj["Cost"] >0:
                insert_sql = '''INSERT INTO ty_dataeye_cost 
                        (create_date,total_cost,view_num,click_nums,medium,account,plan_name,medium_plan_id,business_id,adt_name) 
                        VALUES ('{create_date}',{total_cost},{view_num},{click_nums},'{medium}','{account}','{plan_name}',{ad_id},{business_id},'{adt_name}') 
                        on CONFLICT (create_date,medium_plan_id,account) 
                        DO UPDATE set total_cost = EXCLUDED.total_cost,view_num=EXCLUDED.view_num,click_nums=EXCLUDED.click_nums,adt_name=EXCLUDED.adt_name,
                        plan_name=EXCLUDED.plan_name'''.format(
                    create_date=obj["Date"],
                    total_cost=obj["Cost"],
                    view_num=obj["Impression"],
                    click_nums=obj["Click"],
                    medium="今日头条",
                    account=obj["AccountName"],
                    plan_name=obj["Adtname"],  # 锋红计划名称
                    ad_id=obj["AdId"],
                    business_id=obj["BusinessId"],
                    adt_name=obj["PlanName"]   # 媒体投放名称
                )
                self.pg.execute(insert_sql)

        else:
            print("解析日报报表数据")

    # 数据清洗到pg 获取落地页 等信息 (business_id 公司信息 adt_name 锋红投放名称)
    def GetPage(self,business_id,adt_name):
        sql = "select id as page_id,app_id as pid,channel_id as rid from ty_page where name = '%s' "%(adt_name)
        dblink = "host=localhost port=3002 dbname=tianyan_{business_id} user=tianyan password=Wuaf!@#comTydaHan52".format(
            business_id=business_id)
        db_sql = "select dblink('{db_link}'，'{sql}')".format(db_link=dblink, sql=sql)
        self.pg.query_one(db_sql)
