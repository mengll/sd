# _*_ coding: utf8 _*_
# 数据库相关的连接
# 异步循序的开启关闭
import asyncio

from common.common import get_current_datetime
from common.config import Config
from common.database import pg_client, mysql_client

class SmsBase(object):
    def __init__(self):
        # 天眼数据库
        pg_name = "postgresql"
        self.pg = pg_client(Config().get_config(pg_name, 'host'),
                       Config().get_config(pg_name, 'port'),
                       Config().get_config(pg_name, 'database'),
                       Config().get_config(pg_name, 'username'),
                       Config().get_config(pg_name, 'password'))

        # anfeng_profile
        pg_name = "anfeng_profile"
        self.profile = pg_client(Config().get_config(pg_name, 'host'),
                            Config().get_config(pg_name, 'port'),
                            Config().get_config(pg_name, 'database'),
                            Config().get_config(pg_name, 'username'),
                            Config().get_config(pg_name, 'password'))

        # 安峰
        adv_mysql_name = "anfeng_sdk"
        self.af_mysql = mysql_client(Config().get_config(adv_mysql_name, 'host'),
                                  Config().get_config(adv_mysql_name, 'port'),
                                  Config().get_config(adv_mysql_name, 'database'),
                                  Config().get_config(adv_mysql_name, 'username'),
                                  Config().get_config(adv_mysql_name, 'password'))

        # 团团
        adv_mysql_name = "tuantuan_sdk"
        self.tt_mysql = mysql_client(Config().get_config(adv_mysql_name, 'host'),
                                      Config().get_config(adv_mysql_name, 'port'),
                                      Config().get_config(adv_mysql_name, 'database'),
                                      Config().get_config(adv_mysql_name, 'username'),
                                      Config().get_config(adv_mysql_name, 'password'))

        # 团玩
        adv_mysql_name = "tuanwan_sdk"
        self.tw_mysql = mysql_client(Config().get_config(adv_mysql_name, 'host'),
                                      Config().get_config(adv_mysql_name, 'port'),
                                      Config().get_config(adv_mysql_name, 'database'),
                                      Config().get_config(adv_mysql_name, 'username'),
                                      Config().get_config(adv_mysql_name, 'password'))

        self.loop = asyncio.get_event_loop()


    def __enter__(self):
        print("开始同步：{start}".format(start=get_current_datetime()))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.loop.close()
        print("数据同步完成:{end}".format(end=get_current_datetime()))
        locals()
