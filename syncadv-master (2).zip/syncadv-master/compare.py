# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 今日头条marketing
import datetime
import sys
import time
import asyncio
from dataBase import dataBase

from marketing.jrtt.sync import SyncDat

pages = {}

def get_timestamp_day(day,time_stmp =time.time()):
    day_temp = time.strftime("%Y-%m-%d",time.localtime(int(time_stmp)))
    day_temp = datetime.datetime.strptime(day_temp,"%Y-%m-%d")
    back = day_temp + datetime.timedelta(days=day)
    print(back)
    return int(back.timestamp())


def initpage(db):
    start_ts = get_timestamp_day(-100)
    dat = db.query("select id,name from af_page where status = 'normal' and create_time > {start_ts}".format(start_ts=start_ts))
    for item in dat:
        pages[item["name"]] = item["id"]

def getChannel(db,pid):
    dat = db.query("select channel_id from ty_page where app_id = %d and status = 'normal' and create_time <= 1548086400 and rtype = 3"%pid)
    datas = []
    for item in dat:
        datas.append("'%s'"%item[0])

    return datas
deviceid = [
'221.219.141.48',
'39.128.177.199',
'111.25.77.32',
'101.249.23.214',
'113.70.71.127',
'125.81.157.193',
'27.201.218.1',
'223.116.185.222',
'171.212.252.241',
'122.7.42.132',
'183.212.3.7',
'223.104.185.207',
'223.96.152.79',
'49.94.20.204',
'112.9.212.33',
'223.104.217.160',
'171.120.98.63',
'117.136.82.203',
'106.40.157.90',
'113.129.158.20',
'183.167.17.18',
'221.192.178.134',
'125.85.239.241',
'221.13.63.39',
'223.104.3.236',
'220.191.253.79',
'117.136.73.46',
'111.41.250.192',
'110.89.203.194'
    ]

if __name__ == "__main__":
    with dataBase(mongo_name="mongodb_sdk", db_name="dsp") as db:
        # dat = getChannel(db.pg, 2159)
        # rids = ','.join(dat)
        # print(rids)
        j = 0
        # db.pg.query("select * from ty_device_active_new where pid = %d and rid in")


        mg = db.mg["adtdata"].find({'gameid':"2826",'status':{'$gte':-1},'clicktime':{'$gt':1551801600,'$lt':1551888000}})

        for item in mg:
            #print(item['deviceid'],",",item['sign'],",",item['active_time'],",",)
            ip = item['ip']
            p = deviceid.__contains__(ip)
            if p :
                print(item['ip'],item['muid'],item["rid"])
            pass