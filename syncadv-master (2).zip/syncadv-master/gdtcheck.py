# _*_ coding: utf8 _*_
# 广点通广告数据排查
from common.common import get_time_stmp
from common.common_old import convert_timestamp_to_date_format
from dataBase import dataBase

import pandas as pd
ISDEBUG =False

def check_gdt(sdk,dsp,ty,gameid=3475,ac=9833659,adgroup=None,start_ts=1567958400,end_ts=1568044800):
    click = dsp["gdt_click"]
    deviceinfo = sdk["device_info_log"]
    if adgroup is None:
        dt = click.find({"advertiserid":"{ac}".format(ac=ac),"clicktime":{"$gte":"{st}".format(st=start_ts),"$lt":"{et}".format(et=end_ts)}})
    else:
        dt = click.find({"advertiserid":"{ac}".format(ac=ac),"adgroupid":"$in:[{adgroup}]".format(adgroup=adgroup),"clicktime":{"$gte":"{st}".format(st=start_ts),"$lt":"{et}".format(et=end_ts)}})
    muids = []
    for item in dt:
        if item["muid"] != '':
            muids.append("'%s'"%item["muid"])
    muids = list(set(muids))
    muids_str = ','.join(muids)
    run_sql = "select * from ty_device_active_new where  pid={pid} and muid in ({muid_str}) and active_date = 20190908".format(pid=gameid,muid_str=muids_str)
    if ISDEBUG :
        print(run_sql)
    ty_data = ty.query(run_sql)
    ty_data_num = len(ty_data)

    # 获取天眼的设备信息
    ty_device = []
    for ty_item in ty_data:
        ty_device.append(ty_item["deviceid"])

    # 最终设备
    last_device = []
    change_num = 0
    no_change = 0
    # 获取设备的登录更改信息
    for imei in ty_device:
        device_list = deviceinfo.find({"pid":gameid,"imei":imei}).sort("create_ts:1")
        device_info = []
        indec_rid = 0
        index_version = 0
        now_rid = 0
        now_version =0

        for index,device in enumerate(device_list):
            rid = device["rid"]
            version = device["version"]
            ts = convert_timestamp_to_date_format(device["create_ts"])
            if index ==0:
                indec_rid = rid
                now_rid = rid
                index_version = version
                now_version = version
                device_info.append({"imei": imei, "pid": pid, "rid": rid, "version": version,"date":ts})

            if index > 1:
                if rid != now_rid or  now_version != version:
                    device_info.append({"imei":imei,"pid":pid,"rid":rid,"version":version,"date":ts})
                    now_rid = rid
                    now_version = version

        if len(device_info) == 1:
            no_change += 1

        if len(device_info) > 1:
            change_num += 1
            last_device.append(device_info)

    last_num = len(ty_device)
    print("-------匹配到了%d-----变更：%d---------未变更：%d"%(last_num,change_num,no_change))
    for last_item in last_device:
        for num ,info in enumerate(last_item):
            if num == 0:
                print("---------设备：{imei}----pid:{pid}-----rid:{rid}------version:{version}----date:{date}---------------------".format(imei=info["imei"],pid=gameid,
                                                                                   rid=info["rid"],
                                                                                   version=info["version"],date=info["date"]))
            if num > 0:
                print("-----------------------------------变更后-------rid:{rid}------version:{version}----date:{date}".format(rid=info["rid"],version=info["version"],date=info["date"]))

        print("\n")


def checkgdt(dsp,ty,gameid=3475,ac_date=20191011,ac=9833659,adgroup=None):
    click = dsp["gdt_click"]
    gdt_bind = dsp["wx_gdt"]

    start_ts,end_ts = get_time_stmp(ac_date)
    if adgroup is None:
        dt = click.find({"advertiserid": "{ac}".format(ac=ac),
                         "clicktime": {"$gte": "{st}".format(st=start_ts), "$lt": "{et}".format(et=end_ts)}})
    else:
        dt = click.find({"advertiserid": "{ac}".format(ac=ac), "adgroupid": "$in:[{adgroup}]".format(adgroup=adgroup),
                         "clicktime": {"$gte": "{st}".format(st=start_ts), "$lt": "{et}".format(et=end_ts)}})
    muids = []
    muid_plan = {}
    check_paln = []
    for item in dt:
        if item["muid"] != '':
            adid = item["adgroupid"]
            if adid not in check_paln:
                bind = gdt_bind.find({"adid":adid})
                for item_bound in bind:
                    check_paln.append(adid)
                    pass
                    # 检查是否绑定

            muids.append("'%s'" % item["muid"])
            muid_plan[item["muid"]] = item["adgroupid"]

    muids_str = ','.join(muids)

    run_sql = "select ty_device_active_new.*,ty_page.name from ty_device_active_new LEFT JOIN ty_page on ty_device_active_new.page_id = ty_page.id  where pid={pid} and muid in ({muid_str}) ".format(pid=gameid,muid_str=muids_str)
    if ISDEBUG :
        print(run_sql)

    ty_data = ty.query(run_sql)
    datas = []
    for item in ty_data:
        # dat = {"deviceid":item["deviceid"],"active_date":item["active_date"],"name":item["name"],"adid":muid_plan[item["muid"]]}
        datas.append([item["deviceid"],item["active_date"],item["name"],muid_plan[item["muid"]]])

    df = pd.DataFrame(datas,columns=['deviceid','active_date', 'name', 'adid'])
    df.to_csv("{pid}_{ac}_{date}.csv".format(pid=gameid,ac=ac,date=ac_date))

if __name__ == "__main__":

    active_date = 20190905
    pid = "3475"
    rid = "112950"

    with dataBase(mongo_name="newdsp", db_name="dsp") as db:
        # gameid=3475,ac 账号id,adgroup=广告id,start_ts=开始时间,end_ts=结束时间
        #check_gdt(db.mg,db.new_mg,db.pg,gameid=3475,ac=9833659,adgroup=None,start_ts=1567872000,end_ts=1567958400)
        checkgdt(db.new_mg, db.pg, gameid=3181, ac_date=20191014, ac=10038276, adgroup=None)

