# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 今日头条marketing
import datetime
import sys
import time
import asyncio
from dataBase import dataBase

from marketing.jrtt.sync import SyncDat

pages = {}

def get_timestamp_day(day,time_stmp =time.time()):
    day_temp = time.strftime("%Y-%m-%d",time.localtime(int(time_stmp)))
    day_temp = datetime.datetime.strptime(day_temp,"%Y-%m-%d")
    back = day_temp + datetime.timedelta(days=day)
    print(back)
    return int(back.timestamp())


def initpage(db):
    start_ts = get_timestamp_day(-100)
    dat = db.query("select id,name from af_page where status = 'normal' and create_time > {start_ts}".format(start_ts=start_ts))
    for item in dat:
        pages[item["name"]] = item["id"]

# 广告刷量的操作
if __name__ == "__main__":
    with dataBase(mongo_name="mongodb_sdk", db_name="dsp") as db:
        mg = db.mg["adt_dailyreports"].find({}).limit(1000)
        ac = db.mg["adt_adcreative"]
        assets = db.mg["adt_assets"]

        for item in mg:
            ad_id = int(item["adid"])
            dt = ac.find_one({"ad_id":ad_id})

            if dt is not None:
                tp = dt["type"]
                assets_dat = None
                if tp == 1:
                    video_id = dt['video_id']
                    assets_dat = assets.find_one({"video_id": video_id})

                if tp == 2:
                    image_id = dt["image_id"]
                    assets_dat = assets.find_one({"image_id":image_id})
                if assets_dat is not None:
                    print("素材", assets_dat, dt["image_id"],dt["video_id"],dt["title"])


