# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
# 清洗 今日头条marketing
import datetime
import hashlib
import sys
import time
import asyncio

import requests

from dataBase import dataBase

from marketing.jrtt.sync import SyncDat

pages = {}

def get_timestamp_day(day,time_stmp =time.time()):
    day_temp = time.strftime("%Y-%m-%d",time.localtime(int(time_stmp)))
    day_temp = datetime.datetime.strptime(day_temp,"%Y-%m-%d")
    back = day_temp + datetime.timedelta(days=day)
    print(back)
    return int(back.timestamp())


def initpage(db):
    start_ts = get_timestamp_day(-100)
    dat = db.query("select id,name from af_page where status = 'normal' and create_time > {start_ts}".format(start_ts=start_ts))
    for item in dat:
        pages[item["name"]] = item["id"]

def getChannel(db,pid):
    dat = db.query("select channel_id from ty_page where app_id = %d and status = 'normal' and create_time <= 1548086400 and rtype = 3"%pid)
    datas = []
    for item in dat:
        datas.append("'%s'"%item[0])

    return datas
deviceid = [
'58.219.14.79',
'180.140.218.16',
'180.140.218.16',
'111.196.210.150',
'61.158.148.12',
'223.104.188.234',
'183.67.56.194',
'117.139.65.57',
'223.104.147.123',
'119.123.166.73',
'1.197.46.251',
'113.226.55.63',
'113.5.3.121',
'119.39.3.141',
'183.214.50.70',
'36.23.115.34',
'58.59.111.58',
'114.228.153.34',
'111.167.7.63',
'117.136.87.105',
'117.136.95.205',
'223.104.185.53',
'14.30.1.10',
'61.158.148.27',
'39.149.152.211',
'222.129.17.38',
'1.199.247.122',
'27.203.162.191',
'106.34.77.86',
'223.104.147.135',
'223.104.247.193',
'106.119.63.159',
'139.207.86.17',
'112.224.71.215',
'36.62.160.218',
'113.57.182.6',
'223.104.145.33'
    ]

def get_obj_md5(obj):
    md5obj = hashlib.md5()
    md5obj.update(str(obj).encode('utf-8'))
    return md5obj.hexdigest()

def get_akey(pg,pid,rid):
    dt = pg.query("select * from ty_dsp_trace where pid = '%s' and rid = '%s'"%(pid,rid))
    if len(dt) ==1:
        ak = dt[0]['akey']
        return ak

if __name__ == "__main__":
    with dataBase(mongo_name="mongodb_sdk", db_name="dsp") as db:
        # dat = getChannel(db.pg, 2159)
        # rids = ','.join(dat)
        # print(rids)
        games = [{"pid":3475,"rid":108461},{"pid":2848,"rid":76430}]
        for game in games:
            j = 0
            dat = db.pg.query("with pay as ( select * from ty_user_orders where pid = {pid} and rid = {rid} )select pay.ip,tu.imei,md5(tu.imei) as muid,pay.pid,pay.create_time,pay.fee from pay INNER JOIN ty_user_meta_data as tu on pay.ucid = tu.ucid and pay.create_date >=20190312"
                              .format(pid=game['pid'],rid=game['rid']))
            for item in dat:
                #mg = db.mg["adtdata"].find_one({"gameid":"2826",'$or':[{'muid':item["muid"]},{"ip":item["ip"]}]})
                mg = db.mg["adtdata"].find_one({"gameid":"{pid}".format(pid=game['pid']),'muid':item["muid"]})
                #mg = db.mg["adtdata"].find_one({"gameid": "2826", 'ip': item["ip"],'channel':7,'business_id':0})
                if mg is not None:
                    backurl = str(mg["backurl"]).replace("{{ATYPE}}","orders").replace("{{AVALUE}}",str(int(item['fee'])))
                    akey =  get_akey(db.pg, mg["gameid"], mg["rid"])

                    sign = get_obj_md5("%s%s"%(backurl,akey))
                    back_url = "%s&sign=%s"%(backurl,sign)
                    dta = requests.get(back_url)
                    data = dta.json()
                    #{"error_code": 0, "error_msg": "success"}
                    search_data = str(mg["clickid"]).split("_")
                    search_id = search_data[0]
                    clickts   = search_data[1]
                    back = ['%s'%search_id,'%s'%item["imei"],'%s'%clickts,'%s'%item["create_time"],'%s'%back_url]
                    print(','.join(back))
