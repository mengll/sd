from dataBase import dataBase

if __name__ == "__main__":

    active_date = 20190905
    plan_list = ["145dnfgcs3","112dnfgcs15","145dnfgcs1","145dnfgcs3","145dnfgcs9"]
    with dataBase(mongo_name="newdsp", db_name="dsp") as db:
        for name in plan_list:
            dt = db.pg.query("select * from ty_page where name = '{name}'".format(name=name))
            item = dict(dt[0])
            print(item)
