# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
import json


import bson
import requests

from common.common import get_obj_md5, get_current_timestamp
from connectMongo import dataBase
from urllib import  parse

def copy():
    print("sdk mongo to ")
    pass


if __name__ == "__main__":
    with dataBase(mongo_name="newdsp", db_name="dsp") as db:
     
        doc = db.new_mg["adtdata"]
        pid="2284"
        muid=get_obj_md5("869542048457551")
        dt = doc.find({'gameid':"%s"%pid,'muid':"%s"%muid})

        for adt in dt:
                print(adt)
                # # 百度上报
                # if channel == 7:
                #     baidu(db, adt)

                # # 今日头条
                # if channel == 1:
                #     jr =requests.get(adt['backurl'])
                #     print("jr=>",jr)
                #

                # updateArgs = {'$set': {'status': 1}}
                # if channel == 20:
                #     jr =requests.get(adt['backurl'])
                #     print("快手=>",jr.content,muid)
                #     doc.update({'gameid':"%s"%pid,'muid':"%s"%muid,"business_id":7},updateArgs)

    