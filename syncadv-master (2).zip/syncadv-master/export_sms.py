import datetime
import math
import os
import time

import pandas as pd
from SmsBase  import SmsBase
from common import common

# 人群切分设置 每个人群的最大人数
MAN_MAX_LIMIT = 30000

# 是否开始
IS_OPEN_LIMIT = False

# 抓取的游戏id
#gameid = 4

# 正在运行的游戏名称
af_name = '帝国征服者'
tt_name = '雷霆霸业'
tw_name = ''
gamename = ''
# 开启调试
IS_DEBUG = False

# 公司主体 导手机号用
IS_AF,IS_TT,IS_TW = False,False,False

# 开始时间
START_DAY = "2019-08-15"

# 保存路径
SAVE_PATH = ""

def savefile(func):
    def save(*args, **kwargs):
        data =func(*args, **kwargs)
        index = data["index"]
        datas = data["data"]
        pages = 1 if len(datas) < MAN_MAX_LIMIT else math.ceil(len(datas) / MAN_MAX_LIMIT)
        print(pages,math.ceil(len(datas) / MAN_MAX_LIMIT))
        for page in range(pages):
            print("page=>",page,len(datas))
            dt = []

            if len(datas) - page * MAN_MAX_LIMIT > MAN_MAX_LIMIT :
                dt = datas[page * MAN_MAX_LIMIT : (page+1) * MAN_MAX_LIMIT]

            if len(datas) - page * MAN_MAX_LIMIT < MAN_MAX_LIMIT:
                dt = datas[page * MAN_MAX_LIMIT : len(datas)]

            file_name = gamename+"_"+"%s"%START_DAY+"_"+"%s"%index+"_"+"%s"%(page+1)+".txt"
            paths = common.get_path()

            # 主体名称
            complan = ""
            if IS_AF:
                complan = "anfeng"
            if IS_TT:
                complan = "tuantuan"
            if IS_TW:
                complan = "tuanwan"

            tpath = os.path.join(paths,"datalog",complan, gamename,START_DAY,"")
            if os.path.exists(tpath) == False:
                os.makedirs(tpath,0o777)

            file_path = os.path.join(tpath,file_name)
            with open(file_path,mode='w') as file_handle:
                file_handle.write("mobile\n")
                file_handle.write('\n'.join(dt))

    return save


def saveonefile(func):
    def save(*args, **kwargs):
        data =func(*args, **kwargs)
        index = data["index"]
        datas = data["data"]
        pages = 1 if len(datas) < MAN_MAX_LIMIT else math.ceil(len(datas) / MAN_MAX_LIMIT)
        print(pages,math.ceil(len(datas) / MAN_MAX_LIMIT))
        for page in range(pages):
            print("page=>",page,len(datas))
            dt = []

        if len(datas) - page * MAN_MAX_LIMIT > MAN_MAX_LIMIT :
            dt = datas[page * MAN_MAX_LIMIT : (page+1) * MAN_MAX_LIMIT]

        if len(datas) - page * MAN_MAX_LIMIT < MAN_MAX_LIMIT:
            dt = datas[page * MAN_MAX_LIMIT : len(datas)]

        file_name = gamename+"_"+"%s"%START_DAY+".txt"
        paths = common.get_path()

        # 主体名称
        complan = ""
        if IS_AF:
            complan = "anfeng"
        if IS_TT:
            complan = "tuantuan"
        if IS_TW:
            complan = "tuanwan"

        tpath = os.path.join(paths,"datalog",complan, gamename,START_DAY,"")
        if os.path.exists(tpath) == False:
            os.makedirs(tpath,0o777)

        file_path = os.path.join(tpath,file_name)
        with open(file_path,mode='a+') as file_handle:
            file_handle.write("mobile\n")
            file_handle.write('\n'.join(dt))

    return save


def getprojectid(db,gamename):
    rows = db.query("select id from procedures_project where name ='{gamename}'".format(gamename=gamename))
    for item in rows:
        gameid = item['id']
        return gameid

def getdays(num):
    today = datetime.datetime.strptime(START_DAY,"%Y-%m-%d")
    oneday=datetime.timedelta(days=num-1)
    yesterday=today-oneday
    return yesterday.strftime("%Y-%m-%d")

# 获取留存日期
def getliveday(start_day,day):
    today = datetime.datetime.strptime(start_day, "%Y-%m-%d")
    oneday = datetime.timedelta(days=day)
    yesterday = today + oneday
    return yesterday.strftime("%Y%m%d")


#查询条件 未登录【7，15）单笔充值金额最大值 1000>=money>500
@savefile
def dmp_1(db,index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money >={max} and t.max_pay>{min}
    '''.format(gameid=gameid,day7=getdays(7),day15=getdays(15),max=1000,min=500)
    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])

    return {"index":index,"data":datas}
#查询条件 未登录【7，15）单笔充值金额最大值 money >500  M < 1000 总充值
@savefile
def dmp_2(db,index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money <{max} and t.max_pay>{min}
    '''.format(gameid=gameid,day7=getdays(7),day15=getdays(15),max=1000,min=500)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


#查询条件 未登录【7，15）单笔充值金额最大值  200 < money <=500  M >= 1000 总充值
@savefile
def dmp_3(db,index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money >={sum_pay} and t.max_pay>{sg_min} and t.max_pay <= {sg_max}
    '''.format(gameid=gameid,day7=getdays(7),day15=getdays(15),sum_pay=1000,sg_max=500,sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

#查询条件 未登录【7，15）单笔充值金额最大值  200 < money <=500  M < 1000 总充值
@savefile
def dmp_4(db,index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money <{sum_pay} and t.max_pay>{sg_min} and t.max_pay <= {sg_max}
    '''.format(gameid=gameid,day7=getdays(7),day15=getdays(15),sum_pay=1000,sg_max=500,sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


#查询条件 未登录【7，15）单笔充值金额最大值  0 < money <=200  M >= 1000 总充值
@savefile
def dmp_5(db,index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money >={sum_pay} and t.max_pay <= {sg_min}
    '''.format(gameid=gameid,day7=getdays(7),day15=getdays(15),sum_pay=1000,sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 查询条件 未登录【7，15）单笔充值金额最大值  0 < money <=200  M < 1000 总充值
@savefile
def dmp_6(db, index,gameid):
    runsql = '''
        select
        distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day7}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day15}'
        and a.mobile !='' group by a.ucid) t where t.money < {sum_pay} and t.max_pay <= {sg_min}
    '''.format(gameid=gameid, day7=getdays(7), day15=getdays(15), sum_pay=1000, sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 查询条件 未登录【3，7）单笔充值金额最大值   M >= 1000 总充值
@savefile
def dmp_7(db, index,gameid):
    runsql = '''
        select
            distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day3}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day7}'
        and a.mobile !='' group by a.ucid) t where t.money >= {sum_pay}
     '''.format(gameid=gameid, day3=getdays(3), day7=getdays(7), sum_pay=1000, sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 查询条件 未登录【3，7）单笔充值金额最大值   M >= 1000 总充值
@savefile
def dmp_8(db, index,gameid):
    runsql = '''
        select
            distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day3}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day7}'
        and a.mobile !='' group by a.ucid) t where t.money >= {sg_min} and t.money < {sum_pay}
     '''.format(gameid=gameid, day3=getdays(3), day7=getdays(7), sum_pay=1000, sg_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


# 查询条件 未登录【3，7）单笔充值金额最大值   200 >M >= 1 总充值
@savefile
def dmp_9(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day3}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day7}'
          and a.mobile !='' group by a.ucid) t where t.money < {sum_pay}
       '''.format(gameid=gameid, day3=getdays(3), day7=getdays(7), sum_pay=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}



# 查询条件 未登录【15，30）单笔充值金额最大值   M >= 1000 总充值
@savefile
def dmp_10(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day15}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day30}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_pay}
       '''.format(gameid=gameid, day15=getdays(15), day30=getdays(30), sum_pay=1000)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


# 查询条件 未登录【15，30）单笔充值金额最大值   1000 > M >= 200 总充值
@savefile
def dmp_11(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day15}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day30}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_min} and t.money < {sum_max}
       '''.format(gameid=gameid, day15=getdays(15), day30=getdays(30), sum_max=1000,sum_min=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


# 查询条件 未登录【15，30）单笔充值金额最大值   200 > M >= 1 总充值
@savefile
def dmp_12(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day15}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day30}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_min} and t.money < {sum_max}
       '''.format(gameid=gameid, day15=getdays(15), day30=getdays(30), sum_max=200,sum_min=1)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 查询条件 未登录【30，45）单笔充值金额最大值   M >= 1000 总充值
@savefile
def dmp_13(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day30}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day45}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_min} 
       '''.format(gameid=gameid, day30=getdays(30), day45=getdays(45),sum_min=1000)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}


# 查询条件 未登录【30，45）   1000 > M >= 200 总充值
@savefile
def dmp_14(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day30}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day45}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_min} and t.money <{sum_max}
       '''.format(gameid=gameid, day30=getdays(30), day45=getdays(45),sum_min=200,sum_max=1000)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 查询条件 未登录【30，45）   200 > M >= 1 总充值
@savefile
def dmp_15(db, index,gameid):
    runsql = '''
          select
              distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
          from ucusers a
          inner join procedures b on a.pid=b.pid
          inner join procedures_project c on b.project_id=c.id
          inner join orders d on a.ucid=d.ucid and d.status > 0
          where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{day30}'
          and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{day45}'
          and a.mobile !='' group by a.ucid) t where t.money >={sum_min} and t.money <{sum_max}
       '''.format(gameid=gameid, day30=getdays(30), day45=getdays(45),sum_min=1,sum_max=200)

    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])
    return {"index": index, "data": datas}

# 单笔充值金额 大于10 单笔小于 100 总充值 大于等于100
@savefile
def dmp_18(db,index,gameid):
    runsql = getsql(gameid,1,2,{">":10,"<=":100},{">=":100})
    rows = db.query(runsql)
    if IS_DEBUG:
        print(runsql)
    datas = []
    for item in rows:
        datas.append(item['mobile'])

    return {"index": index, "data": datas}


# 简化简化sql拼接 未登录天数，[7,15) S 单笔充值范围 S:{">=":200,"<":100} 单笔充值  M:{">=":1000} 总充值条件 T：{">=":10} 充值次数
def getsql(gameid,min_day,max_day,S={},M={}):
    runsql = '''select distinct mobile from ( select a.ucid, min(mobile) as mobile,sum(d.fee) as money, max(d.fee) as max_pay, count(d.id) as pay_times
        from ucusers a
        inner join procedures b on a.pid=b.pid
        inner join procedures_project c on b.project_id=c.id
        inner join orders d on a.ucid=d.ucid and d.status > 0
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') <= '{min_day}'
        and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') > '{max_day}'
        and a.mobile !='' group by a.ucid) t where 1=1
    '''.format(gameid=gameid,min_day=getdays(min_day),max_day=getdays(max_day),max=1000,min=500)

    last_sql = [runsql]

    # 单笔充值金额
    for k in S:
         last_sql.append("t.max_pay "+k+" %s"%S.get(k))

    # 总充值
    for m in M:
         last_sql.append("t.money "+m+" %s"%M.get(m))
    return " and ".join(last_sql)

# 某天发短信后的留存情况  单笔充值范围 S:{">=":200,"<":100}  M:{">=":1000} 总充值条件 引入新的消费
def exportDaydata(export_day,min_day,max_day,S={},M={}):
    in_sql = getsql(min_day,max_day,S,M)
    run_sql = '''
        SELECT count(distinct mobile),t.money from (
        select a.ucid,min(a.mobile) as mobile, sum(e.fee) as money from ucusers a
        inner join procedures b on a.pid=b.pid 
        inner join procedures_project c on b.project_id=c.id 
        inner join orders e on a.ucid=e.ucid and e.status > 0 
        where c.id = {gameid} and DATE_FORMAT(a.last_login_at,'%Y-%m-%d') >= '{export_day}' and a.mobile !='' and a.mobile in (
         {in_sql}
        )
        group by a.ucid) t 
        where t.money>=0
    '''.format(export_day=export_day,gameid=gameid,in_sql=in_sql)
    print("===>",run_sql)


# 生成唯一值存数据库中
def save_to_pg():
    #todo
    pass

# 解析数据留存
def get_left_man(file_path,start_day,step,db,game_name):
    game_id= getprojectid(db,game_name)
    for parent, dirnames, filenames in os.walk(file_path):
        try:
            for filename in filenames:
                fpath = os.path.join(parent, filename)
                now_line = 0
                with open(fpath, 'r', newline='') as file:
                    count = len(file.readlines())
                    print("【文件总行数{file_name}----{tol_num}】".format(file_name=fpath,tol_num=count))
                    file.seek(0)
                    mobiles = []
                    for item in file:
                        now_line = now_line +1
                        try:
                            if item.strip() != "" and item.strip() != "mobile":
                                    mobiles.append(item.strip())
                        except RuntimeError  as e:
                            print("【错误解析】",e.__str__(),e,item)
                    if len(mobiles) == 0:
                        print("-------------[%d]---start---------" % step)
                        print("召回:{back_man} ,付费人数:{pay_man} 付费金额:{pay_money}".format(back_man=0,
                                                                                      pay_man=0,
                                                                                      pay_money=0))
                        print("-------------[%d]---end---------" % step)
                        continue

                    # 1 通过mobile 获取ucid
                    ucids = get_ucid(db,mobiles,game_id)

                    # 2 通过ucid 获取召回的用户
                    user_active = get_active_user(db,start_day,step,ucids)

                    # 3 获取召回的人付费
                    user_pay,pay_num  = get_user_pay(db,start_day,step,ucids)
                    print("-------------[%d]---start---------"%step)
                    print("召回:{back_man} ,付费人数:{pay_man} 付费金额:{pay_money}".format(back_man=user_active,pay_man=user_pay,pay_money=pay_num))
                    print("-------------[%d]---end---------" % step)
                print('【执行行数】%d'%now_line)

        except RuntimeError as e:
            print("【文件错误】",e.__str__(),item)

# get  通过手机号获取 ucid
def get_ucid(db,mobiles,game_id):
    run_sql = '''
            select a.ucid
            from ucusers a
            inner join procedures b on a.pid=b.pid
            inner join procedures_project c on b.project_id=c.id
            where c.id = {game_id}
            and a.mobile in (
               {mobile}
            )
       '''.format(game_id=game_id, mobile=",".join(mobiles))
    if IS_DEBUG :
        print("get_ucid_sql:",run_sql)
    users = db.query(run_sql)
    ucids = ''
    for item in users:
        ucids += "%d"% item['ucid']+","
    return ucids.rstrip(',')

# 获取活跃用户信息
def get_active_user(db,start_day,step,ucids):
    dt = time.strptime(start_day,"%Y-%m-%d")
    ts = time.strftime("%Y%m%d",dt)
    end_day = getliveday(start_day,step)
    run_sql = '''select count( distinct ucid) as ac_num from ucuser_login_log where ucid in ({users}) and
     date  >= {start_day}  and date < {end_day}'''.format(end_day=end_day,users=ucids,start_day=ts)

    if IS_DEBUG:
        print("get_active_user:", run_sql)
    active_user = db.query(run_sql)

    return active_user[0]['ac_num'] if len(active_user) >0 else 0

# 获取服务的充值情况
def get_user_pay(db,start_day,step,ucids):
    dt = time.strptime(start_day,"%Y-%m-%d")
    ts = time.strftime("%Y-%m-%d 00:00:00",dt)
    end_day = getliveday(start_day,step)
    end_ts = time.strptime(end_day, "%Y%m%d")
    end_time = time.strftime("%Y-%m-%d 00:00:00", end_ts)
    run_sql = '''select count(DISTINCT ucid) as pay_num,sum(fee) as total_fee
from orders where ucid in({users}) and createTime >= '{start_day}' and createTime < '{end_day}' and status > 0'''\
        .format(end_day=end_time,users=ucids,start_day=ts)
    if IS_DEBUG :
        print("user_pay: ",run_sql)
    active_user = db.query(run_sql)
    if len(active_user) >0:
        return active_user[0]['pay_num'],active_user[0]['total_fee'] if active_user[0]['total_fee'] is not None else 0
    return 0,0

# 导出dmp
def export_deviceid_dmp(db,tags,tag_name):
    tag_str =''
    for item in tags:
        tag_str = tag_str + '%d'%item+','
    print("000--->",tag_str)
    tag_str = tag_str.rstrip(',')
    run_sql = '''
        with ty as (
          select distinct device_id from device_profile
          where play_game_id_list && (
             select array_agg(id) from game  where tag_list && ARRAY[{tags}]
          ) and length(device_id) > 20
        ) select device_id::text as muid from ty 
    '''.format(tags=tag_str)
    if IS_DEBUG :
        print(run_sql)
    dat = db.query(run_sql)
    data_list = []
    for item in dat:
        data_list.append(item['muid'])
    df = pd.DataFrame(data_list)
    df.to_csv("%s.csv"%tag_name,index=None,header=None)

# 导出手机号
def export_mobile_dmp(db,tags,tag_name):
    tag_str = ''
    for item in tags:
        tag_str = tag_str + '%d' % item + ','
    tag_str = tag_str.rstrip(',')
    run_sql = '''
         with ty as (
          select distinct UNNEST(mobile_number) as mobile from user_profile
          where play_game_id_list && (
             select array_agg(id) from game  where tag_list && ARRAY[{tags}]
          )
        ) select mobile::text as mobile from ty 

    '''.format(tags=tag_str)
    if IS_DEBUG:
        print(run_sql)
    dat = db.query(run_sql)
    data_list = []
    for item in dat:
        data_list.append(item['mobile'])
    df = pd.DataFrame(data_list)
    df.to_csv("%s.csv" % tag_name, index=None,header=None)

if __name__ == "__main__":
    # 设置目录
    paths = common.get_path()
    base_path = os.path.join(paths, "olddata")
    af_path = os.path.join(base_path, "anfeng")
    tt_path = os.path.join(base_path, "tuantuan")
    tw_path = os.path.join(base_path, "tuanwan")


    #getsql(7,15,{">=":200,"<":100},{">=":1000})
    #exportDaydata(START_DAY,7,15,{">=":1,"<":1000},{">=":1000})

    with SmsBase() as db:
        # 获取留存
        # get_left_man(af_path, '2019-08-08', 3, db.af_mysql,"雷霆霸业")
        #get_left_man(tt_path, '2019-08-02', 7, db.tt_mysql,"雷霆霸业")
        #get_left_man(tw_path, '2019-08-02', 7, db.tw_mysql,"全民宫斗")

        export_mobile_dmp(db.profile,[47,102],'仙侠-传奇-20190810-dmp')

        ## export mobile
        run_sql = [ v for v in range(1,16)]
        if IS_AF:
            gamename = af_name
            gameid = getprojectid(db.af_mysql,af_name)
            for k,b in enumerate(run_sql,1):
                eval("dmp_%d"%b)(db.af_mysql,k,gameid)

        if IS_TT:
            gamename = tt_name
            gameid = getprojectid(db.tt_mysql, tt_name)
            for k,b in enumerate(run_sql,1):
                eval("dmp_%d"%b)(db.tt_mysql,k,gameid)

        if IS_TW:
            gamename = tw_name
            gameid = getprojectid(db.tw_mysql, tw_name)
            for k,b in enumerate(run_sql,1):
                eval("dmp_%d"%b)(db.tw_mysql,k,gameid)