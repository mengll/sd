# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
import json

import pandas as pd

from common.common_old import get_timestamp_day

DEFAULT_FAILED    = -1
PLAN_UPDATE_KEY   = " ON CONFLICT (channel_id, muid, plan_id, creative_id) do update set status = excluded.status "

from dataBase import dataBase

def sync_ocpc(mg,pg):
    mg_db = mg["adtdata"]
    start_time = get_timestamp_day(-1)  # 当前时间的前一天重新跑
    dt = mg_db.find({"gameid":'2898',"rid":'62130',"status":{'$gte':1},"clicktime":{"$gte":1545148800}})

    data_list = []
    for item in dt:
        print("==>",item)
        ita = [item['apptype'],item['uid'],item['appid'],item['clickid'],item['muid'],item['clicktime']]
        data_list.append(ita)

    df = pd.DataFrame(data_list,columns=['app_type','advertiser_id', 'appid', 'click_id', 'muid','click_time'])
    df.to_csv("wechat.csv")


if __name__ == '__main__':
    with dataBase(mongo_name="mongodb_sdk",db_name="dsp") as db:
        sync_ocpc(db.mg,db.pg)



