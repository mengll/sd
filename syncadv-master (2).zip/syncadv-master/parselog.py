# _*_ coding: utf8 _*_
###########################
# @desc    新版解析日志文件
# @metea   解析的日志信息放入到Kafka中
# @author  mll@anfan.com
# @date    2018-07-11
###########################

import datetime
import time
import os
from sphinx.util import requests

class NginxLogPase (object):
    def __init__(self,address,file_path,group_id):
        self.kafka_address = address
        self.file_path     = file_path
        self.group_id = group_id

    def __enter__(self):

        self.start_time = self.gen_timestamp()

        print("【开始解析时间】" ,datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        print("【结束解析时间】", datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    # 加载当前的文件配置
    def get_path(self):
        path = os.path.split(os.path.realpath(__file__))[0]
        return path

    def decode_base64(self, data):
        missing_padding = len(data) % 4
        if missing_padding != 0:
            data += '=' * (4 - missing_padding)
        return data

    def gen_timestamp(self):
        return int(time.time())

    def temp_file_path(self,pname="complete"):
        tpath = os.path.join("/data/wwwlogs", pname)
        dt = datetime.datetime.now().strftime("%Y-%m-%d")
        temp = os.path.join(tpath, dt)
        if (os.path.exists(temp) == False):
            os.makedirs(temp)
        return temp


if __name__ == "__main__":
    path = "datalog"
    with NginxLogPase("172.18.253.195:9092,172.18.254.24:9092,172.18.254.23:9092",path,"async_login") as f:
        f.parse_nginx_log()



