# _*_ coding: utf8 _*_

from kafka import KafkaConsumer

if __name__ == "__main__":
    kafka_consumer = KafkaConsumer(bootstrap_servers="172.18.253.247:9092,172.18.253.248:9092,172.18.253.234:9092",
                                   # group_id=Config().get_config('kafka', 'group_id'),
                                   group_id='sdkinit_test',
                                   auto_offset_reset='earliest',
                                   enable_auto_commit=True)
    kafka_consumer.subscribe(["sdkapi-event-5"])
    for msg in kafka_consumer:
        #print(msg.value)
        cont = msg.value.decode('utf-8')
        print(cont)
