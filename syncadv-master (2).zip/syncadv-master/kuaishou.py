# _*_ coding: utf8 _*_
# @email mll@anfan.com
# 武汉掌游科技
import json

import requests
import pandas as pd

from common.common import get_obj_md5, get_current_timestamp
from common.common_old import convert_timestamp_to_datetime, convert_timestamp_to_date_format
from dataBase import dataBase
from urllib import  parse

iptables = {}

# 清除重复的点击数据
def clearncopy(mg,pid,start,end):
    dt = mg.new_mg["adtdata"].find({"gameid":str(pid),"clicktime":{"$gte":start,"$lt":end},"channel":20})
    iptables[str(pid)] = []

    ips = {}
    for info in dt:
        data = dict(info)
        dta = mg.new_mg["adtdata"].find({"gameid": "%d" % pid,"ip":data["ip"],"business_id":data["business_id"],"channel":20}).count()
        if dta >5:
            pids = list(iptables[str(pid)])
            nums = pids.count(data["ip"])
            ipa =  ips.get(data['ip'])
            if ipa is not None:
                print("hadexits")
                continue
            if pids.__contains__(data["ip"]):
                continue
            ips[data['ip']] =1
            ita = [dta, data['ip'], data['ad_id'], data['cid'],data['muid'],data['backurl'],data['clicktime']]
            iptables[str(pid)].append(ita)
            pids.append(data["ip"])
            print("重复数据=》点击数 %d  ip:%s muid:%s ad_id:%s cid:%s clicktime:%d"%(dta,data["ip"],data["muid"],data["ad_id"],data["cid"],data["clicktime"]))
            #mg.new_mg["adtdata"].delete_one({"gameid": "%d" % pid,"muid":data["muid"],"business_id":data["business_id"],"status":-1})
            # updateArgs = {'$set': {'status': 1}}
            # mg.new_mg["adtdata"].update_many({"gameid": "%d" % pid,"ip":data["ip"],"business_id":data["business_id"]},update=updateArgs)

    df = pd.DataFrame(iptables[str(pid)],columns=['click_num','ip', 'ad_id', 'cid','muid','backurl','click_time'])
    df.to_csv("快手_%d.csv"%pid)


# 导出激活数据
def dumpactive(mg,pid,start,end):
    dt = mg.new_mg["adtdata"].find({"gameid": str(pid), "active_time": {"$gte": start, "$lt": end}, "channel": 20})
    actives = []

    for data in dt:
        ita = [data['ip'], data['ad_id'], data['cid'], data['muid'], data['backurl'], data['clicktime']]
        actives.append(ita)

    df = pd.DataFrame(actives, columns=['ip', 'ad_id', 'cid', 'muid', 'backurl', 'click_time'])
    df.to_csv("快手激活_%d.csv" % pid)


# 清除上报的
def updatemonet(mg, pid, start, end):
        dt = mg.new_mg["adtdata"].find({"gameid": str(pid),"ip":"", "active_time":0})
        for info in dt:
            data = dict(info)
            print(data)
            updateArgs = {'$set': {'status': 1}}
            mg.new_mg["adtdata"].update_many(
                {"gameid": "%d" % pid, "muid": data["muid"], "business_id": data["business_id"], "active_time":0,"channel":{"$ne":20}},
                update=updateArgs)

# 快手数据查询
def compare_ocpc(pg,mg,pid,rid,active_date):
    run_sql = "select muid,deviceid from ty_device_active_new where pid = {pid} and rid = {rid} and active_date = {active_date}".format(
        pid = pid,
        active_date =active_date,
        rid = rid
    )

    dat = pg.query(run_sql)
    dt = mg["adtdata"]

    total = len(dat)  # 天眼的激活总数
    not_found = 0    # 未能匹配到
    in_other_channel = 0  # 分到其它渠道
    compare = 0  # 完全匹配到的
    report_num = 0 # 成功上报的数据
    other_adt_byip = 0  # 通过IP分配到其它的媒体上的

    # 归因到其它渠道的
    rids = []
    other_muids = []

    #not found
    not_found_muids = []

    # click_log_find

    click_log_found = {}

    # 广告点击日志
    click_log = mg["ocpc_click"]

    # ip_click_data
    ip_click_data = []

    # ips 未匹配到的IP信息
    report_by_ip = 0

    for item in dat:
        source = dt.find({"gameid": str(pid),"muid":item["muid"]})
        num = source.count()
        if num == 0:
            not_found += 1
            not_found_muids.append(item["muid"])
            click_dat = click_log.find({"gameid": str(pid),"muid":item["muid"]})

            ip_list = []

            # 通过点击日志查找到的数据
            if click_dat.count() > 0 :
                for click_d in click_dat:
                    click_log_found[item["muid"]] = click_d["ip"]

                    if click_d["ip"] != "":
                    # 通过ip点击的广告数
                        source_ip = dt.find({"gameid": str(pid), "ip": click_d["ip"]})
                        num_ip = source_ip.count()
                        if num_ip > 0:
                            for ip_item in source_ip:
                                # if ip_item["channel"] !=20:
                                if ip_item["status"] >= 1:
                                    report_by_ip += 1

                                if ip_item["muid"] not in ip_list:

                                    ip_list.append(ip_item["muid"])
                                    ip_click_data.append({"muid":ip_item["muid"],"ip":click_d["ip"],"channel":ip_item["channel"],
                                                          "business_id":ip_item["business_id"],"status":ip_item["status"],"imei":item["deviceid"],"ipnum":num_ip
                                                          })
            else:
                print("不知道哪来的",item)

        for content in source:
            tt = dict(content)
            if tt["rid"] != rid:
                in_other_channel += 1
                rids.append(tt["rid"])
                other_muids.append(tt["muid"])

            if tt["rid"] == rid:
                compare += 1

            if tt["status"] >= 1:
                report_num += 1

    print("天眼激活:{active_ty},  未能归因匹配到:{not_found} ,分到其它渠道 :{in_other_channel} -【{rids}】, 完全能匹配到:{compare} ,成功上报:{report_num},通过ip:{ip_num}".format(
        active_ty=total,not_found=not_found,in_other_channel=in_other_channel,compare=compare,report_num=report_num,ip_num=report_by_ip,rids=",".join(rids)
    ))

    # print("-------------------------------未匹配的设备信息-------------------------------------------------------")
    # print("not_foun=>\n","\n".join(not_found_muids))

    print("-------------------------------未匹配到在点击日志中匹配到「{click_num}」-------------------------------------------------".format(click_num=len(ip_click_data)))
    for item in ip_click_data:
        print(item)


# ocpc 数据大于天眼数据
def bigger_ocpc(pg,mg,pid,rid,active_date):
    pass

# 匹配数据异常导出
def export_data(pg,mg,sdk,pid,active_date):
    run_sql = "select muid,deviceid from ty_device_active_new where pid = {pid} and active_date >= {active_date}".format(
        pid = pid,
        active_date =active_date
    )

    dat = pg.query(run_sql)
    dt = mg["adtdata"]
    ip_list = []
    for item in dat:
        source = dt.find({"gameid": str(pid),"muid":item["muid"]})
        num = source.count()
        if num == 0:
            # 未匹配到设备箱
            #item["deviceid"]
            ip_dat = sdk["device_info_log"].find({"imei":item["deviceid"],"pid":int(pid)})
            for ip_item in ip_dat:
                source_ip = dt.find({"gameid": str(pid), "ip": ip_item["ip"]})
                num = source_ip.count()
                if num == 0:
                    if item["deviceid"] not in ip_list:
                        ip_list.append("{imei},{ip}".format(imei=item["deviceid"],ip=ip_item["ip"]))


    print("\n".join(ip_list))


# 数据导出 同一个IP 不同的设备
def expot_byip(mg,pid):
    dt = mg["adtdata"]
    datas = []
    dat = ['223.104.101.61','221.192.178.165','221.192.179.225','223.104.63.154',
           '223.104.103.45','223.104.192.121','221.207.37.34','117.136.86.251','221.192.178.41','117.136.86.251']
    for item in dat:
        source = dt.find({"gameid": str(pid), "ip": str(item),"channel":20})
        for ip_item in source:
            datas.append("{ip},{muid},{clicktime},{ad_id},{cid}".format(ip=ip_item["ip"],muid=ip_item["muid"],clicktime=str(ip_item["clicktime"]),ad_id=str(ip_item["ad_id"]),cid=str(ip_item["cid"])))

    print("\n".join(datas))


# 广点通广告数据排查
def check_gdt(sdk,dsp,ty,gameid=3475,ac=9833659,adgroup=None,start_ts=1567958400,end_ts=1568044800):
    click = dsp["gdt_click"]
    deviceinfo = sdk["device_info_log"]
    if adgroup is None:
        dt = click.find({"advertiserid":"{ac}".format(ac=ac),"clicktime":{"$gte":"{st}".format(st=start_ts),"$lt":"{et}".format(et=end_ts)}})
    else:
        dt = click.find({"advertiserid":"{ac}".format(ac=ac),"adgroupid":"$in:[{adgroup}]".format(adgroup=adgroup),"clicktime":{"$gte":"{st}".format(st=start_ts),"$lt":"{et}".format(et=end_ts)}})
    muids = []
    for item in dt:
        if item["muid"] != '':
            muids.append("'%s'"%item["muid"])
    muids = list(set(muids))
    muids_str = ','.join(muids)
    run_sql = "select * from ty_device_active_new where  pid={pid} and muid in ({muid_str}) and active_date = 20190908".format(pid=gameid,muid_str=muids_str)
    if ISDEBUG :
        print(run_sql)
    ty_data = ty.query(run_sql)
    ty_data_num = len(ty_data)

    # 获取天眼的设备信息
    ty_device = []
    for ty_item in ty_data:
        ty_device.append(ty_item["deviceid"])

    # 最终设备
    last_device = []
    change_num = 0
    no_change = 0
    # 获取设备的登录更改信息
    for imei in ty_device:
        device_list = deviceinfo.find({"pid":gameid,"imei":imei}).sort("create_ts:1")
        device_info = []
        indec_rid = 0
        index_version = 0
        now_rid = 0
        now_version =0

        for index,device in enumerate(device_list):
            rid = device["rid"]
            version = device["version"]
            ts = convert_timestamp_to_date_format(device["create_ts"])
            if index ==0:
                indec_rid = rid
                now_rid = rid
                index_version = version
                now_version = version
                device_info.append({"imei": imei, "pid": pid, "rid": rid, "version": version,"date":ts})

            if index > 1:
                if rid != now_rid or  now_version != version:
                    device_info.append({"imei":imei,"pid":pid,"rid":rid,"version":version,"date":ts})
                    now_rid = rid
                    now_version = version

        if len(device_info) == 1:
            no_change += 1

        if len(device_info) > 1:
            change_num += 1
            last_device.append(device_info)

    last_num = len(ty_device)
    print("-------匹配到了%d-----变更：%d---------未变更：%d"%(last_num,change_num,no_change))
    for last_item in last_device:
        for num ,info in enumerate(last_item):
            if num == 0:
                print("---------设备：{imei}----pid:{pid}-----rid:{rid}------version:{version}----date:{date}---------------------".format(imei=info["imei"],pid=gameid,
                                                                                   rid=info["rid"],
                                                                                   version=info["version"],date=info["date"]))
            if num > 0:
                print("-----------------------------------变更后-------rid:{rid}------version:{version}----date:{date}".format(rid=info["rid"],version=info["version"],date=info["date"]))

        print("\n")



def info_log(sdk):
    ops = ['869838046168541',
'866508038206772',
'867027046403312',
'862123038825177',
'862245033482272',
'867300035472915',
'860469047944539',
'868375038460009',
'A10000532375F2',
'867541036737695',
'863709036185215',
'864592030896675',
'863478034766307',
'99001155077296',
'863549038422699',
'866239038038755',
'866412030431688',
'868994042211917',
'868026026431391',
'869838042655004',
'866738045860903',
'865413032167016',
'862058049747855',
'867649037886856',
'869705033301833',
'868381036597990',
'869103049988357',
'866111036596821',
'869598041975460',
'865320032803625',
'863455043852518',
'865737031043129',
'866049036852200',
'862839043184074',
'864728034403882',
'861761045061277',
'868773036919358',
'860596034952099',
'352936097267222',
'868382033082804',
'868961020731265',
'990008695701958',
'860172047814310',
'867215044958110',
'864371045832573',
'865787040572899',
'869714036938435',
'861997041417432',
'862986035035390']
    deviceinfo = sdk["device_info_log"]
    last_device = []
    change_num = 0
    no_change = 0
    gameid = 3475
    for imei in ops:
        device_list = deviceinfo.find({"pid": 3475, "imei": imei}).sort("create_ts:1")
        device_info = []
        indec_rid = 0
        index_version = 0
        now_rid = 0
        now_version = 0

        for index, device in enumerate(device_list):
            rid = device["rid"]
            version = device["version"]
            ts = convert_timestamp_to_date_format(device["create_ts"])
            if index == 0:
                indec_rid = rid
                now_rid = rid
                index_version = version
                now_version = version
                device_info.append({"imei": imei, "pid": pid, "rid": rid, "version": version, "date": ts})

            if index > 1:
                if rid != now_rid or now_version != version:
                    device_info.append({"imei": imei, "pid": pid, "rid": rid, "version": version, "date": ts})
                    now_rid = rid
                    now_version = version

        if len(device_info) == 1:
            no_change += 1

        if len(device_info) > 1:
            change_num += 1
            last_device.append(device_info)

    last_num = len(last_device)
    print("-------匹配到了%d-----变更：%d---------未变更：%d"%(last_num,change_num,no_change))
    for last_item in last_device:
        for num ,info in enumerate(last_item):
            if num == 0:
                print("---------设备：{imei}----pid:{pid}-----rid:{rid}------version:{version}----date:{date}---------------------".format(imei=info["imei"],pid=gameid,
                                                                                   rid=info["rid"],
                                                                                   version=info["version"],date=info["date"]))
            if num > 0:
                print("-----------------------------------变更后-------rid:{rid}------version:{version}----date:{date}".format(rid=info["rid"],version=info["version"],date=info["date"]))

        print("\n")

ISDEBUG = False
if __name__ == "__main__":

    active_date = 20190905
    pid = "3475"
    rid = "112950"
    with dataBase(mongo_name="newdsp", db_name="dsp") as db:
        info_log(db.mg)
        # gameid=3475,ac 账号id,adgroup=广告id,start_ts=开始时间,end_ts=结束时间
        # check_gdt(db.mg,db.new_mg,db.pg,gameid=3475,ac=9833659,adgroup=None,start_ts=1567872000,end_ts=1567958400)
        #compare_ocpc(db.pg,db.new_mg,pid,rid,active_date)
        #export_data(db.pg,db.new_mg,db.mg,pid,active_date)
        #expot_byip(db.new_mg,pid)
