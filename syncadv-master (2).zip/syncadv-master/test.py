import datetime
import json
import time

import ctypes

from common import common
from common.common_old import convert_datetime_to_timestamp

if __name__ == "__main__":
    # yd = common.get_yesterday(1).ctime()
    # tf = time.strptime(yd, "%Y-%m-%d")
    # print(tf)


    # ys = convert_datetime_to_timestamp(yd)
    # print(ys)
    # dll = ctypes.WinDLL("WeChatWin.dll")
    # pass
    #
    # t = time.strftime("%H",time.localtime())
    # tf = time.strptime("2019-01-01 02:02:03","%Y-%m-%d %H:%M:%S")
    # print(tf.tm_hour)
    # context = '''
    #     {"ad_id":1623343151250461,"advertiser_id":110276487971,"audit_reject_reason":null,"creative_id":1623343440705576,"creative_word_ids":[],"image_id":null,"image_ids":["web.business.image/201901215d0d5656a3eae494409cb5b0"],"image_mode":"CREATIVE_IMAGE_MODE_LA^CRGE","metarials":[{"audit_reject_reason":null,"image_id":null,"title":"某男子提款机前玩这个传奇，竟然忘记了取钱！","video_id":null},{"audit_reject_reason":null,"image_id":"web.business.image/201901215d0d5656a3eae494409cb5b0","title":null,"video_id":null}],"opt_status":"CREATIVE_STATUS_ENABLE","status":"CREATIVE_STATUS_AD_DISABLE","third_party_id":null,"title":"某男子提款机前玩这个传奇，竟然忘记了取钱！","video_id":null}
    # '''
    #
    # obj = json.loads(context,encoding="utf-8")
    # metarials = obj["metarials"]  # 素材文件
    # print("创意=》", metarials, "\n")
    #
    # if len(metarials) > 0:
    #     for item in metarials:
    #         sub_title = item["title"]
    #         image_id  = item["image_id"]
    #         video_id  = item["video_id"]
    #         if sub_title is not None :
    #             if image_id is not None:
    #                 print("sub-img=>",image_id)
    #
    #             if video_id is not None:
    #                 print("video_id",video_id)
    #
    #
    # title = "tt-dytt5srcq40-人群包+视频0201"
    # dt = title.split("-",2)
    # print(dt,len(dt))