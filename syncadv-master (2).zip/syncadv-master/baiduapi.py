#!/usr/bin/python
# encoding=utf8

import os
import sys
import urllib

import json
import hashlib
import hmac
import time
import datetime
from urllib.parse import urlparse, quote


def gen_auth(access_key, secret_key, utc_time_str, url, method):
    url_parse_ret = urlparse(url)
    host = url_parse_ret.hostname
    path = url_parse_ret.path
    version = "1"
    expiration_seconds = "1800"
    signature_headers = "host"

    # 1 Generate SigningKey
    val = "bce-auth-v%s/%s/%s/%s" % (version, access_key, utc_time_str, expiration_seconds)
    signing_key = hmac.new(secret_key, val, hashlib.sha256).hexdigest().encode('utf-8')

    # 2 Generate CanonicalRequest
    # 2.1 Genrate CanonicalURI
    canonical_uri = quote(path)
    # 2.2 Generate CanonicalURI: not used here
    # 2.3 Generate CanonicalHeaders: only include host here
    canonical_headers = "host:%s" % quote(host).strip()
    # 2.4 Generate CanonicalRequest
    canonical_request = "%s\n%s\n\n%s" % (method.upper(), canonical_uri, canonical_headers)

    # 3 Generate Final Signature
    signature = hmac.new(signing_key, canonical_request, hashlib.sha256).hexdigest()
    authorization = "bce-auth-v%s/%s/%s/%s/%s/%s" % (
    version, access_key, utc_time_str, expiration_seconds, signature_headers, signature)
    print(authorization)
    return authorization


if __name__ == "__main__":
    # 替换成你的AK/SK, 带有xxxx的自己填充,https://console.bce.baidu.com/iam/?_=1499420345823#/iam/accesslist
    access_key = "b11cb3b79cc3407291653ab46f217528"
    secret_key = "d597fca4cdc246d8a66d10b4f2c2592b"
    url = "http://sem.baidubce.com/v1/feed/cloud/CreativeFeedService/addCreativeFeed"
    method = "POST"
    utc_time = datetime.datetime.utcnow()
    utc_time_str = utc_time.strftime("%Y-%m-%dT%H:%M:%SZ")
    auth = gen_auth(access_key, secret_key, utc_time_str, url, method)

    print(auth)

    #header = {
    #     'accept-encoding': 'gzip, deflate',
    #     'host': 'sem.baidubce.com',
    #     'content-type': 'application/json',
    #     'x-bce-date': utc_time_str,
    #     'authorization': auth,
    #     'accept': '*/*'
    # }
    # data = {
    #     "body": {
    #         "creativeFeedTypes": [
    #             {
    #                 "creativeFeedName": "idea_3037293",
    #                 "materialstyle": 303,
    #                 "adgroupFeedName": "unit_2586",
    #                 "adgroupFeedId": "2539340784",
    #                 "material": "{ \"title\": \"idea_303\",\"pictures\": [ { \"image\": \"http://bj.bcebos.com/fc-feed/0/pic/ec8bfac5b80442a74047dc8210582b83.jpg\"} ],\"brand\": \"a推广\", \"url\": \"http://shen.com/\" }"
    #             }
    #         ]
    #     },
    #     "header": {
    #         "opUsername": "xxxx",
    #         "tgUsername": "xxxx",
    #         # https://console.bce.baidu.com/iam/?_=1499420345823#/iam/baseinfo, 从这里可以看
    #         "bceUser": "xxxx",
    #         "opPassword": "xxxx",
    #         "tgPassword": "xxxx"
    #     }
    # }
    #
    # data = json.dumps(data)
    # request = urllib2.Request(url, data, header)
    # response = None
    # try:
    #     response = urllib2.urlopen(request)
    #     post_res_str = response.read()
    #     print(post_res_str)
    # except urllib2.URLError as e:
    #     print("URLError")
    #     print (e.code, e.reason)
    #     print(e.read())
    # except urllib2.HTTPError as e:
    #     print("HTTPError")
    #     print(e.code, e.reason)
    #     print(e.read())